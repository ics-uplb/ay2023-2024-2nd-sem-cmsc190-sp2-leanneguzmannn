import { NavigationContainer } from "@react-navigation/native";
import { StatusBar } from "expo-status-bar";
import React, { useEffect, useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import "react-native-gesture-handler";
import { ToastProvider } from "react-native-toast-notifications";
import { auth } from "./backend/firebase"; // Import db
import firebaseAPI from "./backend/firebase-api";
import { COLORS } from "./frontend/assets";
import AuthNavigator from "./frontend/navigation/AuthNavigator";
import {
  horizontalScale,
  moderateScale,
  verticalScale,
} from "./frontend/utilities/Scaling";
import CustomToast from "./utilities/CustomToast";
import { UserProvider } from "./utilities/UserProvider";

export default function App() {
  const [currentUser, setCurrentUser] = useState(auth.currentUser);
  const [notificationMessage, setNotificationMessage] = useState({});

  const [mealPlanNotificationShown, setMealPlanNotificationShown] =
    useState(false);
  const [
    expiringIngredientsNotificationShown,
    setExpiringIngredientsNotificationShown,
  ] = useState(false);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setCurrentUser(user); // Update current user state
    });

    return () => unsubscribe(); // Clean up subscription
  }, []);

  useEffect(() => {
    const fetchLowQuantityIngredients = async () => {
      if (currentUser) {
        if (!notificationMessage.body) {
          // Check if the user is logged in
          const lowQuantityIngredients =
            await firebaseAPI.checkIngredientsWithQuantityOne(
              auth.currentUser.uid
            );

          if (lowQuantityIngredients.length > 0) {
            const ingredientNames = lowQuantityIngredients.join(", ");

            const message = `${ingredientNames} ${
              lowQuantityIngredients.length > 1 ? "are" : "is"
            } almost empty. Consider restocking!`;

            setNotificationMessage({
              title: "ATTENTION!",
              body: message,
            });

            await firebaseAPI.saveNotifications({
              message,
              time: new Date().toISOString(),
            });
          }
        }
      }
    };

    const checkMealPlanNotification = async () => {
      if (currentUser) {
        const mealPlanNotification =
          await firebaseAPI.checkMealPlanNotification(auth.currentUser.uid);

        if (mealPlanNotification && !mealPlanNotificationShown) {
          setNotificationMessage(mealPlanNotification);

          await firebaseAPI.saveNotifications({
            message: mealPlanNotification.body,
            time: new Date().toISOString(),
          });

          setMealPlanNotificationShown(true);
        }
      }
    };

    const checkExpiringIngredientsNotification = async () => {
      if (currentUser) {
        const expiringIngredients =
          await firebaseAPI.fetchExpiringIngredients();

        if (
          expiringIngredients.length > 0 &&
          !expiringIngredientsNotificationShown
        ) {
          const ingredientNames = expiringIngredients.join(", ");
          const message = `${ingredientNames} ${
            expiringIngredients.length > 1 ? "are" : "is"
          } near its expiration date. Please use it soon!`;

          setNotificationMessage({
            title: "WARNING!",
            body: message,
          });

          await firebaseAPI.saveNotifications({
            message,
            time: new Date().toISOString(),
          });

          setMealPlanNotificationShown(true);
        }
      }
    };

    fetchLowQuantityIngredients();
    checkMealPlanNotification();
    checkExpiringIngredientsNotification();
  }, [currentUser]);

  return (
    <ToastProvider
      placement="top"
      offset={verticalScale(30)}
      renderType={{
        custom_toast: (toast) => (
          <View
            style={{
              width: "85%",
              paddingHorizontal: horizontalScale(15),
              paddingVertical: verticalScale(10),
              backgroundColor: COLORS.white,
              marginVertical: verticalScale(4),
              borderRadius: moderateScale(8),
              borderLeftColor: COLORS.darkBrown,
              borderLeftWidth: horizontalScale(6),
              justifyContent: "center",
              paddingLeft: horizontalScale(16),
            }}
          >
            <Text style={styles.notifTitle}>{toast.data.title}</Text>
            <Text style={styles.notifContent}>{toast.message}</Text>
          </View>
        ),
      }}
    >
      <UserProvider>
        <NavigationContainer>
          <StatusBar style="light" translucent={true} />
          {notificationMessage?.body && (
            <CustomToast notification={notificationMessage} />
          )}
          <AuthNavigator />
        </NavigationContainer>
      </UserProvider>
    </ToastProvider>
  );
}

const styles = StyleSheet.create({
  notifTitle: {
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(15),
  },
  notifContent: {
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(12),
    color: COLORS.orange,
  },
});
