export default {
  USERS: "usersCollection",
  INGREDIENTS: "ingredientsCollection",
  RECIPES: "recipesCollection",
  GROCERY_LIST: "groceryListCollection",
  HISTORY: "historyCollection",
  MEAL_PLAN: "mealPlanCollection",
  NOTIFICATIONS: "notificationsCollection",
};
