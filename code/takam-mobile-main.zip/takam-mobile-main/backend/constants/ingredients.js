import MEASUREMENTS from "./measurements";

export default {
  ampalaya: {
    name: "Ampalaya",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 7, // days
  },
  achuete: {
    name: "Achuete",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 365, // days, dried seeds
  },
  bacon: {
    name: "Bacon",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 14, // days, refrigerated
  },
  bagoong: {
    name: "Bagoong",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 30, // days, refrigerated
  },
  bayleaf: {
    name: "Bay Leaf",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 365, // days, dried
  },
  beef: {
    name: "Beef",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 14, // days, refrigerated
  },
  bellpepper: {
    name: "Bell Pepper",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 5, // days
  },
  bihon: {
    name: "Bihon",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 365, // days, dried
  },
  breadcrumbs: {
    name: "Breadcrumbs",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 180, // days, dried
  },
  brocolli: {
    name: "Broccoli",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 7, // days
  },
  butter: {
    name: "Butter",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 30, // days, refrigerated
  },
  cabbage: {
    name: "Cabbage",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 14, // days
  },
  calamansi: {
    name: "Calamansi",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 14, // days
  },
  carrot: {
    name: "Carrot",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 14, // days
  },
  cauliflower: {
    name: "Cauliflower",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 7, // days
  },
  cheese: {
    name: "Cheese",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 30, // days, refrigerated
  },
  chicken: {
    name: "Chicken",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 14, // days, refrigerated
  },
  chickenbroth: {
    name: "Chicken Broth",
    measuredBy: MEASUREMENTS.MILLILITERS,
    totalQuantity: 0,
    shelfLife: 7, // days, refrigerated
  },
  chilipepper: {
    name: "Chili Pepper",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 14, // days, fresh
  },
  cookingoil: {
    name: "Cooking Oil",
    measuredBy: MEASUREMENTS.MILLILITERS,
    totalQuantity: 0,
    shelfLife: 365, // days
  },
  corn: {
    name: "Corn",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 7, // days, fresh
  },
  cornstarch: {
    name: "Cornstarch",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 365, // days
  },
  cream: {
    name: "Cream",
    measuredBy: MEASUREMENTS.MILLILITERS,
    totalQuantity: 0,
    shelfLife: 10, // days, refrigerated
  },
  egg: {
    name: "Egg",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 21, // days, refrigerated
  },
  eggnoodles: {
    name: "Egg Noodles",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 365, // days, dried
  },
  eggplant: {
    name: "Eggplant",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 7, // days
  },
  elbowmacaroni: {
    name: "Elbow Macaroni",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 365, // days, dried
  },
  fish: {
    name: "Fish",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 14, // days, refrigerated
  },
  fishsauce: {
    name: "Fish Sauce",
    measuredBy: MEASUREMENTS.MILLILITERS,
    totalQuantity: 0,
    shelfLife: 365, // days
  },
  flour: {
    name: "Flour",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 365, // days
  },
  garlic: {
    name: "Garlic",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 14, // days
  },
  gata: {
    name: "Gata",
    measuredBy: MEASUREMENTS.MILLILITERS,
    totalQuantity: 0,
    shelfLife: 7, // days, fresh
  },
  ginger: {
    name: "Ginger",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 14, // days
  },
  greenpeas: {
    name: "Green Peas",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 14, // days, fresh
  },
  greenpepper: {
    name: "Green Pepper",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 7, // days
  },
  kamote: {
    name: "Kamote",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 21, // days
  },
  kangkong: {
    name: "Kangkong",
    measuredBy: MEASUREMENTS.BUNDLE,
    totalQuantity: 0,
    shelfLife: 5, // days, fresh
  },
  liverspread: {
    name: "Liver Spread",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 5, // days, refrigerated
  },
  lumpiawrapper: {
    name: "Lumpia Wrapper",
    measuredBy: MEASUREMENTS.BUNDLE,
    totalQuantity: 0,
    shelfLife: 14, // days, refrigerated
  },
  malunggay: {
    name: "Malunggay",
    measuredBy: MEASUREMENTS.BUNDLE,
    totalQuantity: 0,
    shelfLife: 7, // days, fresh
  },
  mayonnaise: {
    name: "Mayonnaise",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 90, // days, refrigerated
  },
  milk: {
    name: "Milk",
    measuredBy: MEASUREMENTS.MILLILITERS,
    totalQuantity: 0,
    shelfLife: 7, // days, refrigerated
  },
  monggo: {
    name: "Monggo",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 365, // days, dried
  },
  mushroom: {
    name: "Mushroom",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 7, // days, fresh
  },
  oliveoil: {
    name: "Olive Oil",
    measuredBy: MEASUREMENTS.MILLILITERS,
    totalQuantity: 0,
    shelfLife: 730, // days
  },
  onion: {
    name: "Onion",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 14, // days
  },
  oystersauce: {
    name: "Oyster Sauce",
    measuredBy: MEASUREMENTS.MILLILITERS,
    totalQuantity: 0,
    shelfLife: 180, // days, refrigerated after opening
  },
  pasta: {
    name: "Pasta",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 365, // days, dried
  },
  peanutbutter: {
    name: "Peanut Butter",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 270, // days, unopened
  },
  pechay: {
    name: "Pechay",
    measuredBy: MEASUREMENTS.BUNDLE,
    totalQuantity: 0,
    shelfLife: 7, // days, fresh
  },
  pepper: {
    name: "Pepper",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 1095, // days, ground
  },
  pepperflakes: {
    name: "Pepper Flakes",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 1095, // days, dried
  },
  pork: {
    name: "Pork",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 14, // days, refrigerated
  },
  potato: {
    name: "Potato",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 21, // days
  },
  radish: {
    name: "Radish",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 14, // days
  },
  salt: {
    name: "Salt",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 3650, // days, indefinite if kept dry
  },
  shrimp: {
    name: "Shrimp",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 14, // days, refrigerated
  },
  soysauce: {
    name: "Soy Sauce",
    measuredBy: MEASUREMENTS.MILLILITERS,
    totalQuantity: 0,
    shelfLife: 1095, // days, unopened
  },
  sprite: {
    name: "Sprite",
    measuredBy: MEASUREMENTS.MILLILITERS,
    totalQuantity: 0,
    shelfLife: 7, // days, unopened
  },
  squash: {
    name: "Squash",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 14, // days, whole
  },
  stringbeans: {
    name: "String Beans",
    measuredBy: MEASUREMENTS.BUNDLE,
    totalQuantity: 0,
    shelfLife: 7, // days
  },
  sugar: {
    name: "Sugar",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 1095, // days, indefinite if kept dry
  },
  tamarind: {
    name: "Tamarind",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 7, // days, fresh
  },
  tofu: {
    name: "Tofu",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 7, // days, refrigerated
  },
  tomato: {
    name: "Tomato",
    measuredBy: MEASUREMENTS.PIECES,
    totalQuantity: 0,
    shelfLife: 7, // days
  },
  tomatopaste: {
    name: "Tomato Paste",
    measuredBy: MEASUREMENTS.GRAMS,
    totalQuantity: 0,
    shelfLife: 180, // days, unopened
  },
  vinegar: {
    name: "Vinegar",
    measuredBy: MEASUREMENTS.MILLILITERS,
    totalQuantity: 0,
    shelfLife: 1825, // days, indefinite
  },
};
