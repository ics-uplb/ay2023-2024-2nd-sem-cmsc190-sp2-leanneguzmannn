export default {
  GRAMS: "grams",
  PIECES: "pieces",
  MILLILITERS: "milliliters",
  BUNDLE: "bundle",
};
