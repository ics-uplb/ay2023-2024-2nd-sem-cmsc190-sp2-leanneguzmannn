import * as SecureStore from "expo-secure-store";
import firebase from "firebase/compat/app";
import "firebase/compat/storage";
import moment from "moment";
import { stringToFirebaseTimestamp } from "../utilities/formatDate";
import { DB_COLLECTIONS, INGREDIENTS, RECIPES } from "./constants";
import { auth, db } from "./firebase";

const initializeIngredientsCollection = async (uid) => {
  try {
    const userRef = db.collection(DB_COLLECTIONS.INGREDIENTS).doc(uid);

    // If the user's document already exists, db no longer needs to be initialized
    const userDoc = await userRef.get();
    if (userDoc.exists) {
      console.log("Ingredients collection already initialized for user:", uid);
      return;
    }

    // Initialize ingredients directly under the user's document
    for (const [ingredientId, data] of Object.entries(INGREDIENTS)) {
      await userRef.set(
        {
          [ingredientId]: {
            name: data.name,
            supply: null,
            measuredBy: data.measuredBy,
            totalQuantity: 0,
            shelfLife: data.shelfLife,
          },
        },
        { merge: true }
      );
    }

    console.log("Ingredients collection initialized for user:", uid);
  } catch (error) {
    console.error("Error initializing ingredients collection:", error);
    throw error;
  }
};

const initializeRecipesCollection = async () => {
  try {
    const recipesCollection = db.collection(DB_COLLECTIONS.RECIPES);

    // Check if the recipes collection already exists
    const recipesSnapshot = await recipesCollection.get();
    if (!recipesSnapshot.empty) {
      console.log("Recipes collection already initialized");
      return;
    }

    // Add each recipe to the collection
    for (const [recipeId, recipeData] of Object.entries(RECIPES)) {
      await recipesCollection.doc(recipeId).set(recipeData);
    }

    console.log("Recipes collection initialized successfully");
  } catch (error) {
    console.error("Error initializing recipes collection:", error);
    throw error;
  }
};

const initializeMealPlanCollection = async (uid) => {
  try {
    console.log("Fetching meal plan from Firebase");
    const today = new Date();
    const dayOfWeek = today.getDay();
    const nearestSunday = new Date(today);
    nearestSunday.setDate(today.getDate() - (dayOfWeek === 0 ? 7 : dayOfWeek));

    const mealPlanRef = db.collection(DB_COLLECTIONS.MEAL_PLAN).doc(uid);
    const mealPlanDoc = await mealPlanRef.get();

    if (mealPlanDoc.exists) {
      const mealPlanData = mealPlanDoc.data();
      const lastGeneratedDate = new Date(mealPlanData.lastGeneratedDate);
      const sevenDaysLater = new Date(lastGeneratedDate);
      sevenDaysLater.setDate(sevenDaysLater.getDate() + 7);

      if (today >= sevenDaysLater) {
        const newMealPlanData = {
          lastGeneratedDate: nearestSunday.toISOString().split("T")[0],
          mealPlans: await generateMealPlans(),
        };

        await mealPlanRef.set(newMealPlanData);
        await SecureStore.setItemAsync(
          "mealPlan",
          JSON.stringify(newMealPlanData)
        );
        console.log("Updated meal plan document for user:", uid);

        // Reset meal plan history every time meal plan is also generated
        const historyRef = db.collection(DB_COLLECTIONS.HISTORY).doc(uid);
        await historyRef.set({
          MON: { lunch: "", dinner: "" },
          TUE: { lunch: "", dinner: "" },
          WED: { lunch: "", dinner: "" },
          THU: { lunch: "", dinner: "" },
          FRI: { lunch: "", dinner: "" },
          SAT: { lunch: "", dinner: "" },
          SUN: { lunch: "", dinner: "" },
        });

        return newMealPlanData;
      } else {
        // Check SecureStore for cached meal plan
        const cachedMealPlan = await SecureStore.getItemAsync("mealPlan");

        if (cachedMealPlan !== null) {
          console.log("Fetching meal plan from SecureStore");
          return JSON.parse(cachedMealPlan);
        }
      }

      await SecureStore.setItemAsync("mealPlan", JSON.stringify(mealPlanData));
      return mealPlanData;
    } else {
      const newMealPlanData = {
        lastGeneratedDate: nearestSunday.toISOString().split("T")[0],
        mealPlans: await generateMealPlans(),
      };

      await mealPlanRef.set(newMealPlanData);
      await SecureStore.setItemAsync(
        "mealPlan",
        JSON.stringify(newMealPlanData)
      );
      console.log("Initialized meal plan document for user:", uid);
      return newMealPlanData;
    }
  } catch (error) {
    console.error("Error initializing meal plan data:", error);
    throw new Error("Error initializing meal plan data:", error);
  }
};

const initUponLogin = async () => {
  // Initialize ingredients db right after the user's first login
  await initializeIngredientsCollection(auth.currentUser.uid);
  await initializeRecipesCollection();
  await initializeMealPlanCollection(auth.currentUser.uid);
};

const signUp = async (newUser) => {
  try {
    const userCredentials = await auth.createUserWithEmailAndPassword(
      newUser.email,
      newUser.password
    );

    // Send verification email
    await auth.currentUser.sendEmailVerification({
      handleCodeInApp: true,
      url: "https://takam-mobile-app.firebaseapp.com",
    });

    await userCredentials.user.updateProfile({
      displayName: `${newUser.fName} ${newUser.lName}`,
    });

    await db
      .collection(DB_COLLECTIONS.USERS)
      .doc(userCredentials.user.uid)
      .set({
        uid: userCredentials.user.uid,
        email: newUser.email,
        fName: newUser.fName,
        lName: newUser.lName,
        verified: false,
      });

    console.log(
      "User pre-registered and has received verification email at: ",
      userCredentials.user.email
    );
  } catch (error) {
    let errorMsg = "";
    if (error.code === "auth/email-already-in-use") {
      errorMsg = "The email address is already in use by another account!";
    }

    if (error.code === "auth/invalid/email") {
      errorMsg = "The email address is invalid!";
    }

    if (error.code === "auth/network-request-failed") {
      errorMsg = "Network error";
    }

    console.log(error.message);

    if (errorMsg != "") {
      throw new Error(errorMsg);
    } else {
      throw new Error(error.message);
    }
  }
};

const logIn = async (email, password, setUser) => {
  try {
    const userCredentials = await auth.signInWithEmailAndPassword(
      email,
      password
    );

    // Check if the user is verified
    if (!userCredentials.user.emailVerified && email !== "admin@test.com") {
      throw new Error("Please verify your email address before logging in.");
    }

    const userAuthCred = firebase.auth.EmailAuthProvider.credential(
      email,
      password
    );

    const saveUserAuthCred = {
      ...userAuthCred,
      uid: userCredentials.user.uid,
    };

    await SecureStore.setItemAsync(
      "userAuthCred",
      JSON.stringify(saveUserAuthCred)
    );

    setUser(saveUserAuthCred);

    const user = userCredentials.user;

    // Save the updated Expo push tokens to the user's document in the usersCollection
    await db.collection(DB_COLLECTIONS.USERS).doc(user.uid).update({
      verified: true,
    });

    console.log("Logged in with: ", user.email);
  } catch (error) {
    let errorMsg = "";

    switch (error.code) {
      case "auth/user-not-found":
        errorMsg = "The email address or password does not exist!";
        break;
      case "auth/invalid-email":
        errorMsg = "The email address is invalid!";
        break;
      case "auth/wrong-password":
        errorMsg = "The password is incorrect!";
        break;
      case "auth/network-request-failed":
        errorMsg = "Network error";
        break;
      default:
        errorMsg = error.message;
    }

    console.log("Login error: ", error.message);

    if (errorMsg != "") {
      throw new Error(errorMsg);
    }
  }
};

const fetchUserData = async (userId) => {
  const userRef = db.collection(DB_COLLECTIONS.USERS).doc(userId);
  const userDoc = await userRef.get();
  if (userDoc.exists) {
    return userDoc.data();
  } else {
    throw new Error(`User not found with userId: ${userId}`);
  }
};

const fetchIngredientsList = async (uid) => {
  try {
    const userRef = db.collection(DB_COLLECTIONS.INGREDIENTS).doc(uid);

    const ingredients = [];

    const userDoc = await userRef.get();

    if (userDoc.exists) {
      const userData = userDoc.data();

      for (const ingredientId of Object.keys(userData).sort()) {
        const ingredientData = userData[ingredientId];
        ingredientData.id = ingredientId;

        if (ingredientData.totalQuantity) {
          ingredientData.imageUrl = await fetchIngredientPicture(ingredientId);
        }

        ingredients.push(ingredientData);
      }
    } else {
      console.log("User document not found:", uid);
    }

    return ingredients;
  } catch (error) {
    console.error("Error fetching ingredients:", error);
    throw new Error("Error fetching ingredients:", error);
  }
};

const fetchToAddIngredients = async (uid) => {
  try {
    // Check SecureStore for cached ingredient data
    const cachedIngredients = await SecureStore.getItemAsync(
      `toAddIngredients`
    );

    if (cachedIngredients !== null) {
      console.log("Fetching ingredients from SecureStore");
      return JSON.parse(cachedIngredients);
    }

    console.log("Fetching ingredients from Firebase");
    const userRef = db.collection(DB_COLLECTIONS.INGREDIENTS).doc(uid);

    const ingredients = [];

    const userDoc = await userRef.get();

    if (userDoc.exists) {
      const userData = userDoc.data();

      for (const ingredientId of Object.keys(userData).sort()) {
        const ingredientData = userData[ingredientId];
        ingredientData.id = ingredientId;

        ingredients.push(ingredientData);
      }

      // Cache the fetched ingredient data in SecureStore
      await SecureStore.setItemAsync(
        `toAddIngredients`,
        JSON.stringify(ingredients)
      );
    } else {
      console.log("User document not found:", uid);
    }

    return ingredients;
  } catch (error) {
    console.error("Error fetching to-add ingredients:", error);
    throw new Error("Error fetching to-add ingredients:", error);
  }
};

const fetchIngredientPicture = async (imageFileName) => {
  try {
    // Get the ingredient URL from Firebase Storage
    const storageRef = firebase
      .storage()
      .ref()
      .child(`ingredients/${imageFileName}.png`);
    const url = await storageRef.getDownloadURL();

    return url;
  } catch (error) {
    console.error("Error getting ingredient picture: ", error);
    throw new Error("Error getting ingredient picture: ", error);
  }
};

const updateIngredientSupply = async (userId, ingredientId, supplyData) => {
  try {
    const userRef = db.collection(DB_COLLECTIONS.INGREDIENTS).doc(userId);
    const userDoc = await userRef.get();

    if (userDoc.exists) {
      const userData = userDoc.data();
      const updatedIngredients = { ...userData };

      if (updatedIngredients.hasOwnProperty(ingredientId)) {
        // Update supply data and convert expirationDate to Firebase Timestamp format
        const updatedSupplyData = supplyData.map((supply) => ({
          ...supply,
          expirationDate: stringToFirebaseTimestamp(supply.expirationDate),
        }));

        // Remove supplies with quantity zero
        const filteredSupplyData = updatedSupplyData.filter(
          (supply) => supply.quantity > 0
        );

        // Calculate total quantity
        let totalQuantity = 0;
        filteredSupplyData.forEach((supply) => {
          totalQuantity += parseInt(supply.quantity);
        });

        // Update supply data and totalQuantity
        updatedIngredients[ingredientId].supply = filteredSupplyData;
        updatedIngredients[ingredientId].totalQuantity = totalQuantity;

        // Check if all supplies and totalQuantity are zero
        const allSuppliesZero = filteredSupplyData.every(
          (supply) => supply.quantity === 0
        );

        if (allSuppliesZero) {
          // If all supplies and totalQuantity become zero, set supply to null and totalQuantity to zero
          updatedIngredients[ingredientId].supply = null;
          updatedIngredients[ingredientId].totalQuantity = 0;
        }

        // Update ingredient document
        await userRef.set(updatedIngredients);
        console.log("Supply data successfully updated");
      } else {
        console.error("Ingredient not found in user's data");
        throw new Error("Ingredient not found");
      }
    } else {
      console.error("User document not found:", userId);
      throw new Error("User document not found");
    }
  } catch (error) {
    console.error("Error updating supply data:", error);
    throw new Error("Failed to update supply data");
  }
};

const fetchRecipesList = async () => {
  try {
    // Check AsyncStorage for cached recipes
    const cachedRecipes = await SecureStore.getItemAsync("recipesList");

    if (cachedRecipes !== null) {
      console.log("Fetching recipes from AsyncStorage");
      return JSON.parse(cachedRecipes);
    }

    console.log("Fetching recipes from Firebase");
    const recipesCollection = db.collection(DB_COLLECTIONS.RECIPES);
    const recipes = [];
    const recipesSnapshot = await recipesCollection.get();

    if (!recipesSnapshot.empty) {
      for (const recipeDoc of recipesSnapshot.docs) {
        const recipeData = recipeDoc.data();
        const recipeId = recipeDoc.id;

        // Fetch main image URL
        const mainImageUrl = await fetchRecipeImage(
          `recipes/main-images/${recipeId}`
        );

        // Fetch banner image URL
        const bannerImageUrl = await fetchRecipeImage(
          `recipes/banners/${recipeId}Banner`
        );

        // Add image URLs to recipe data
        recipeData.mainImageUrl = mainImageUrl;
        recipeData.bannerImageUrl = bannerImageUrl;
        recipeData.id = recipeId;

        recipes.push(recipeData);
      }

      // Store the recipes in AsyncStorage
      await SecureStore.setItemAsync("recipesList", JSON.stringify(recipes));
    } else {
      console.log("Recipes collection is empty");
    }

    return recipes;
  } catch (error) {
    console.error("Error fetching recipes:", error);
    throw new Error("Error fetching recipes:", error);
  }
};

const fetchRecipeImage = async (imagePath) => {
  try {
    // Get the recipe image URL from Firebase Storage
    const storageRef = firebase.storage().ref().child(`${imagePath}.png`);
    const url = await storageRef.getDownloadURL();

    return url;
  } catch (error) {
    console.error("Error getting recipe image:", error);
    throw new Error("Error getting recipe image:", error);
  }
};

const addInventory = async (ingredientQuantities) => {
  const today = new Date();

  try {
    const userRef = db
      .collection(DB_COLLECTIONS.INGREDIENTS)
      .doc(auth.currentUser.uid);
    const userDoc = await userRef.get();

    if (userDoc.exists) {
      const userData = userDoc.data();

      Object.keys(ingredientQuantities).forEach(async (ingredientId) => {
        const quantity = Number(ingredientQuantities[ingredientId]);
        const expirationDate = new Date(today);
        expirationDate.setDate(
          expirationDate.getDate() + userData[ingredientId].shelfLife
        );

        if (userData.hasOwnProperty(ingredientId)) {
          const supply = userData[ingredientId].supply || [];

          // Update supplyArray and totalQuantity
          await userRef.update({
            [ingredientId]: {
              ...userData[ingredientId],
              totalQuantity: userData[ingredientId].totalQuantity + quantity,
              supply: [
                ...supply,
                {
                  quantity: quantity,
                  dateAdded: today,
                  expirationDate: expirationDate,
                },
              ],
            },
          });
        } else {
          console.log(
            `Ingredient with id ${ingredientId} does not exist for the current user.`
          );
        }
      });
    } else {
      console.log("User document not found:", auth.currentUser.uid);
    }
  } catch (error) {
    console.error("Error adding ingredients:", error);
    throw new Error("Error adding ingredients:", error);
  }
};

const fetchRecipeData = async (recipeId) => {
  try {
    const recipeRef = db.collection(DB_COLLECTIONS.RECIPES).doc(recipeId);
    const recipeDoc = await recipeRef.get();

    if (recipeDoc.exists) {
      return recipeDoc.data();
    } else {
      console.log("Recipe not found:", recipeId);
      return null;
    }
  } catch (error) {
    console.error("Error fetching recipe data:", error);
    throw new Error("Error fetching recipe data:", error);
  }
};

const checkIngredientsAvailability = async (recipeId) => {
  try {
    // Fetch recipe data
    const recipeData = await fetchRecipeData(recipeId);

    if (!recipeData) {
      console.log("Recipe not found:", recipeId);
      return false; // Recipe not found
    }

    const userRef = db
      .collection(DB_COLLECTIONS.INGREDIENTS)
      .doc(auth.currentUser.uid);
    const userDoc = await userRef.get();

    if (userDoc.exists) {
      const userData = userDoc.data();
      const missingIngredients = [];

      // Loop through ingredients in the recipe
      for (const [ingredientId, quantity] of Object.entries(
        recipeData.ingredients
      )) {
        const ingredientQuantity = Number(quantity);
        const userDataForIngredient = userData[ingredientId];

        if (userDataForIngredient) {
          // Check if the user's ingredient supply is sufficient to cook the recipe
          if (userDataForIngredient.totalQuantity < ingredientQuantity) {
            missingIngredients.push({
              id: ingredientId,
              name: userDataForIngredient.name,
              measuredBy: userDataForIngredient.measuredBy,
              quantity:
                ingredientQuantity - userDataForIngredient.totalQuantity,
            });
          }
        } else {
          console.log(
            `Ingredient with id ${ingredientId} does not exist for the current user.`
          );
          // If ingredient does not exist, add it to the missingIngredients array with required quantity
          missingIngredients.push({
            id: ingredientId,
            name: userDataForIngredient.name,
            measuredBy: userDataForIngredient.measuredBy,
            quantity: ingredientQuantity,
          });
        }
      }

      // If missingIngredients array is empty, all ingredients are available
      if (missingIngredients.length === 0) {
        return [];
      } else {
        return missingIngredients;
      }
    } else {
      console.log("User document not found:", auth.currentUser.uid);
      return false; // User document not found
    }
  } catch (error) {
    console.log("Error checking ingredients availability:", error);
    throw new Error("Error checking ingredients availability:", error);
  }
};

const isCookable = async (recipes, recipeId) => {
  try {
    // Fetch recipe data
    const recipeData = recipes.find((recipe) => recipe.id === recipeId);

    if (!recipeData) {
      console.log("Recipe not found:", recipeId);
      return false; // Recipe not found
    }

    const userRef = db
      .collection(DB_COLLECTIONS.INGREDIENTS)
      .doc(auth.currentUser.uid);
    const userDoc = await userRef.get();

    if (userDoc.exists) {
      const userData = userDoc.data();

      // Loop through ingredients in the recipe
      for (const [ingredientId, quantity] of Object.entries(
        recipeData.ingredients
      )) {
        const ingredientQuantity = Number(quantity);
        const userDataForIngredient = userData[ingredientId];

        if (userDataForIngredient) {
          // Check if the user's ingredient supply is sufficient to cook the recipe
          if (userDataForIngredient.totalQuantity < ingredientQuantity) {
            return false;
          }
        } else {
          console.log(
            `Ingredient with id ${ingredientId} does not exist for the current user.`
          );
          return false;
        }
      }

      // If all ingredients are available, return true
      return true;
    } else {
      console.log("User document not found:", auth.currentUser.uid);
      return false; // User document not found
    }
  } catch (error) {
    console.log("Error checking ingredients availability:", error);
    throw new Error("Error checking ingredients availability:", error);
  }
};

const cookRecipe = async (recipeId) => {
  try {
    // Check if ingredients are available
    const missingIngredients = await checkIngredientsAvailability(recipeId);

    if (missingIngredients.length !== 0) {
      // If there's only one missing ingredient, throw an error with that ingredient's information
      if (missingIngredients.length === 1) {
        const missingIngredient = missingIngredients[0];
        throw new Error(
          `Missing ingredient to cook the recipe: "${missingIngredient.id} ${missingIngredient.quantity} ${missingIngredient.measuredBy} ${missingIngredient.name}" `
        );
      } else {
        throw new Error("Insufficient ingredients to cook the recipe");
      }
    }

    // Fetch recipe data
    const recipeData = await fetchRecipeData(recipeId);

    if (!recipeData) {
      console.log("Recipe not found:", recipeId);
      return;
    }

    const userRef = db
      .collection(DB_COLLECTIONS.INGREDIENTS)
      .doc(auth.currentUser.uid);
    const userDoc = await userRef.get();

    if (userDoc.exists) {
      const userData = userDoc.data();

      // Loop through ingredients in the recipe
      for (const [ingredientId, quantity] of Object.entries(
        recipeData.ingredients
      )) {
        const ingredientQuantity = Number(quantity);
        const userDataForIngredient = userData[ingredientId];

        if (userDataForIngredient) {
          // Calculate remaining quantity to deduct
          let remainingQuantity = ingredientQuantity;

          // Sort the supply array by dateAdded in ascending order
          const ingredientSupply = userDataForIngredient.supply || [];

          // Loop through the sorted supply array
          for (let i = 0; i < ingredientSupply.length; i++) {
            const supplyItem = ingredientSupply[i];
            const supplyQuantity = supplyItem.quantity;

            // Deduct the quantity from the current supply
            if (supplyQuantity >= remainingQuantity) {
              // If the current supply has enough quantity, update it and break the loop
              supplyItem.quantity -= remainingQuantity;
              if (supplyItem.quantity === 0) {
                // If the supply is depleted, remove it
                ingredientSupply.splice(i, 1);
              }
              break;
            } else {
              // If the current supply doesn't have enough quantity, deduct what's available and move to the next supply
              remainingQuantity -= supplyQuantity;
              ingredientSupply.splice(i, 1); // Remove the current supply
              i--; // Decrement i to adjust for the removed element
            }
          }

          // Update total quantity and supply array
          const newTotalQuantity = Math.max(
            0,
            userDataForIngredient.totalQuantity - ingredientQuantity
          );
          const supply = ingredientSupply.length > 0 ? ingredientSupply : null; // If supply is empty, set it to null
          await userRef.update({
            [ingredientId]: {
              ...userDataForIngredient,
              totalQuantity: newTotalQuantity,
              supply: supply,
            },
          });
        } else {
          console.log(
            `Ingredient with id ${ingredientId} does not exist for the current user.`
          );
        }
      }
    } else {
      console.log("User document not found:", auth.currentUser.uid);
    }
  } catch (error) {
    console.log("Error updating ingredients:", error.message);
    throw new Error(error.message);
  }
};

const cookRecipeWithMissingIngredient = async (recipeId, ingredientId) => {
  try {
    // Fetch recipe data
    const recipeData = await fetchRecipeData(recipeId);

    if (!recipeData) {
      console.log("Recipe not found:", recipeId);
      return;
    }

    const userRef = db
      .collection(DB_COLLECTIONS.INGREDIENTS)
      .doc(auth.currentUser.uid);
    const userDoc = await userRef.get();

    if (userDoc.exists) {
      const userData = userDoc.data();

      // Loop through ingredients in the recipe
      for (const [ingId, quantity] of Object.entries(recipeData.ingredients)) {
        if (ingId === ingredientId) {
          await userRef.update({
            [ingredientId]: {
              ...userData[ingredientId],
              totalQuantity: 0,
              supply: null,
            },
          });

          continue;
        }

        const ingredientQuantity = Number(quantity);
        const userDataForIngredient = userData[ingId];

        if (userDataForIngredient) {
          // Calculate remaining quantity to deduct
          let remainingQuantity = ingredientQuantity;

          // Sort the supply array by dateAdded in ascending order
          const ingredientSupply = userDataForIngredient.supply || [];

          // Loop through the sorted supply array
          for (let i = 0; i < ingredientSupply.length; i++) {
            const supplyItem = ingredientSupply[i];
            const supplyQuantity = supplyItem.quantity;

            // Deduct the quantity from the current supply
            if (supplyQuantity >= remainingQuantity) {
              // If the current supply has enough quantity, update it and break the loop
              supplyItem.quantity -= remainingQuantity;
              if (supplyItem.quantity === 0) {
                // If the supply is depleted, remove it
                ingredientSupply.splice(i, 1);
              }
              break;
            } else {
              // If the current supply doesn't have enough quantity, deduct what's available and move to the next supply
              remainingQuantity -= supplyQuantity;
              ingredientSupply.splice(i, 1); // Remove the current supply
              i--; // Decrement i to adjust for the removed element
            }
          }

          // Update total quantity and supply array
          const newTotalQuantity = Math.max(
            0,
            userDataForIngredient.totalQuantity - ingredientQuantity
          );
          const supply = ingredientSupply.length > 0 ? ingredientSupply : null; // If supply is empty, set it to null
          await userRef.update({
            [ingId]: {
              ...userDataForIngredient,
              totalQuantity: newTotalQuantity,
              supply: supply,
            },
          });
        } else {
          console.log(
            `Ingredient with id ${ingId} does not exist for the current user.`
          );
        }
      }
    } else {
      console.log("User document not found:", auth.currentUser.uid);
    }
  } catch (error) {
    console.log("Error updating ingredients:", error.message);
    throw new Error(error.message);
  }
};

// Function to shuffle an array
const shuffleArray = (array) => {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
};

// Function to generate meal plans for lunch and dinner
const generateMealPlans = async () => {
  try {
    const recipesList = await fetchRecipesList();
    let availableRecipes = [...recipesList];

    if (recipesList.length < 14) {
      throw new Error("Not enough recipes to generate meal plans");
    }

    // Check if history data exists
    const historyData = await fetchHistory(auth.currentUser.uid);
    const historyRecipes = Object.values(historyData).reduce(
      (acc, day) => acc.concat(Object.values(day)),
      []
    );

    // Remove history recipe names from available recipes
    availableRecipes = availableRecipes.filter(
      (recipe) => !historyRecipes.includes(recipe.name)
    );

    if (availableRecipes.length < 14) {
      throw new Error("Not enough recipes available after considering history");
    }

    // Shuffle the list of recipes
    const shuffledRecipes = shuffleArray(availableRecipes);

    // Split the shuffled recipes into lunch and dinner
    const lunchRecipes = shuffledRecipes.slice(0, 7);
    const dinnerRecipes = shuffledRecipes.slice(7, 14);

    // Initialize meal plan structure
    const mealPlan = {
      MON: { lunch: "", dinner: "" },
      TUE: { lunch: "", dinner: "" },
      WED: { lunch: "", dinner: "" },
      THU: { lunch: "", dinner: "" },
      FRI: { lunch: "", dinner: "" },
      SAT: { lunch: "", dinner: "" },
      SUN: { lunch: "", dinner: "" },
    };

    // Days of the week
    const daysOfWeek = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];

    // Assign recipes to each day
    daysOfWeek.forEach((day, index) => {
      mealPlan[day].lunch = lunchRecipes[index];
      mealPlan[day].dinner = dinnerRecipes[index];
    });

    return mealPlan;
  } catch (error) {
    console.error("Error generating meal plans:", error);
    throw new Error("Error generating meal plans:", error);
  }
};

const fetchMealPlanData = async (uid) => {
  try {
    // Check SecureStore for cached meal plan
    const cachedMealPlan = await SecureStore.getItemAsync("mealPlan");

    if (cachedMealPlan !== null) {
      console.log("Fetching meal plan from SecureStore");
      return JSON.parse(cachedMealPlan).mealPlans;
    }

    const mealPlanRef = db.collection(DB_COLLECTIONS.MEAL_PLAN).doc(uid);
    const mealPlanDoc = await mealPlanRef.get();

    if (mealPlanDoc.exists) {
      return mealPlanDoc.data().mealPlans;
    } else {
      console.log("Meal plan document not found:", uid);
      // Return a default structure if document does not exist
      return {
        MON: { lunch: {}, dinner: {} },
        TUE: { lunch: {}, dinner: {} },
        WED: { lunch: {}, dinner: {} },
        THU: { lunch: {}, dinner: {} },
        FRI: { lunch: {}, dinner: {} },
        SAT: { lunch: {}, dinner: {} },
        SUN: { lunch: {}, dinner: {} },
      };
    }
  } catch (error) {
    console.error("Error fetching meal plan data:", error);
    throw new Error("Error fetching meal plan data:", error);
  }
};

const fetchGroceryList = async () => {
  try {
    const userRef = db
      .collection(DB_COLLECTIONS.GROCERY_LIST)
      .doc(auth.currentUser.uid);
    const groceryList = [];

    const userDoc = await userRef.get();

    if (userDoc.exists) {
      const userData = userDoc.data();

      for (const groceryId of Object.keys(userData).sort()) {
        const groceryData = userData[groceryId];
        groceryData.id = groceryId;

        groceryList.push(groceryData);
      }
    } else {
      console.log(
        "User document not found, initializing new document for:",
        auth.currentUser.uid
      );
      await userRef.set({});
    }

    // Fetch ingredients with quantity one
    const ingredientsWithQuantityOne = await checkIngredientsWithQuantityOne();

    // Fetch ingredients that are expiring soon
    const expiringIngredients = await fetchExpiringIngredients();

    // Combine both lists
    const allIngredients = [
      ...ingredientsWithQuantityOne,
      ...expiringIngredients,
    ];

    // Filter out duplicate ingredients based on their names
    const uniqueIngredients = allIngredients.filter(
      (ingredient) =>
        !groceryList.some((grocery) => grocery.name === ingredient)
    );

    // Add unique ingredients to the grocery list
    uniqueIngredients.forEach((ingredient) => {
      groceryList.push({
        id:
          groceryList.length > 0
            ? Number(groceryList[groceryList.length - 1].id) + 1
            : 1,
        name: ingredient,
      });
    });

    // Update the groceryList collection in the database with the combined grocery list
    await userRef.set(
      groceryList.reduce((acc, item) => {
        acc[item.id] = { name: item.name };
        return acc;
      }, {})
    );

    return groceryList;
  } catch (error) {
    console.error("Error fetching grocery list:", error);
    throw new Error("Error fetching grocery list:", error);
  }
};

const fetchExpiringIngredients = async () => {
  try {
    const today = moment().startOf("day");
    const tomorrow = today.clone().add(1, "days");

    const userRef = db
      .collection(DB_COLLECTIONS.INGREDIENTS)
      .doc(auth.currentUser.uid);
    const userDoc = await userRef.get();

    const expiringIngredients = [];

    if (userDoc.exists) {
      const userData = userDoc.data();

      for (const ingredientId in userData) {
        const ingredient = userData[ingredientId];
        if (ingredient.supply) {
          const expiringSupply = ingredient.supply.filter((supply) => {
            const expirationDate = moment(supply.expirationDate.toDate());
            return expirationDate.isBetween(today, tomorrow, "day", "[]");
          });
          if (expiringSupply.length > 0) {
            expiringIngredients.push(ingredient.name);
          }
        }
      }
    }

    return expiringIngredients;
  } catch (error) {
    console.error("Error fetching expiring ingredients:", error);
    throw new Error("Error fetching expiring ingredients:", error);
  }
};

const updateGroceryItem = async (itemId, newData) => {
  try {
    const userRef = db
      .collection(DB_COLLECTIONS.GROCERY_LIST)
      .doc(auth.currentUser.uid);

    // Update the specific item in the grocery list
    await userRef.update({
      [itemId]: newData,
    });

    console.log("Grocery item updated successfully:", newData);
  } catch (error) {
    console.error("Error updating grocery item:", error);
    throw new Error("Error updating grocery item:", error);
  }
};

const deleteGroceryItems = async (itemIds) => {
  try {
    const userRef = db
      .collection(DB_COLLECTIONS.GROCERY_LIST)
      .doc(auth.currentUser.uid);

    // Delete each item in the batch operation
    itemIds.forEach(async (itemId) => {
      await userRef.update({
        [itemId]: firebase.firestore.FieldValue.delete(),
      });
      console.log("Item deleted successfully:", itemId);
    });

    console.log("All grocery items deleted successfully.");
  } catch (error) {
    console.error("Error deleting grocery items:", error);
    throw new Error("Error deleting grocery items:", error);
  }
};

const deleteAllGroceryItems = async () => {
  try {
    const userRef = db
      .collection(DB_COLLECTIONS.GROCERY_LIST)
      .doc(auth.currentUser.uid);

    // Clear the entire document
    await userRef.set({});

    console.log("All grocery items deleted successfully.");
  } catch (error) {
    console.error("Error deleting all grocery items:", error);
    throw new Error("Error deleting all grocery items:", error);
  }
};

const checkIngredientsWithQuantityOne = async () => {
  try {
    const userRef = db
      .collection(DB_COLLECTIONS.INGREDIENTS)
      .doc(auth.currentUser.uid);
    const userDoc = await userRef.get();

    if (userDoc.exists) {
      const userData = userDoc.data();
      const ingredientsWithQuantityOne = [];

      for (const ingredientId in userData) {
        const ingredientData = userData[ingredientId];

        if (
          ingredientData.totalQuantity <= 1 &&
          ingredientData.totalQuantity > 0
        ) {
          ingredientsWithQuantityOne.push(ingredientData.name);
        }
      }

      return ingredientsWithQuantityOne;
    } else {
      console.log("User document not found:", auth.currentUser.uid);
      return [];
    }
  } catch (error) {
    console.error("Error checking ingredients with quantity one:", error);
    throw new Error("Error checking ingredients with quantity one:", error);
  }
};

const fetchHistory = async (uid) => {
  try {
    const userRef = db.collection(DB_COLLECTIONS.HISTORY).doc(uid);

    const defaultHistory = {
      MON: { lunch: "", dinner: "" },
      TUE: { lunch: "", dinner: "" },
      WED: { lunch: "", dinner: "" },
      THU: { lunch: "", dinner: "" },
      FRI: { lunch: "", dinner: "" },
      SAT: { lunch: "", dinner: "" },
      SUN: { lunch: "", dinner: "" },
    };

    const userDoc = await userRef.get();

    if (userDoc.exists) {
      return userDoc.data();
    } else {
      console.log(
        "User document not found, initializing new document for:",
        uid
      );
      await userRef.set(defaultHistory);
      return defaultHistory;
    }
  } catch (error) {
    console.error("Error fetching history:", error);
    throw new Error("Error fetching history:", error);
  }
};

const updateHistory = async (uid, historyData) => {
  try {
    const userRef = db.collection(DB_COLLECTIONS.HISTORY).doc(uid);
    await userRef.set(historyData);
    console.log("History data updated successfully.");
  } catch (error) {
    console.error("Error updating history data:", error);
    throw new Error("Error updating history data:", error);
  }
};

const saveNotifications = async (notification) => {
  try {
    const userRef = db
      .collection(DB_COLLECTIONS.NOTIFICATIONS)
      .doc(auth.currentUser.uid);

    // Fetch current notifications to determine the next ID
    const userDoc = await userRef.get();
    const userData = userDoc.exists ? userDoc.data() : {};

    // Determine the next notification ID
    const notifIds = Object.keys(userData).map((id) => parseInt(id));
    const nextId = notifIds.length > 0 ? Math.max(...notifIds) + 1 : 1;

    // Save the new notification with the determined ID
    await userRef.set(
      {
        [nextId]: {
          message: notification.message,
          time: notification.time,
        },
      },
      { merge: true } // Merge with existing document
    );

    console.log("Notification saved successfully.");
  } catch (error) {
    console.error("Error saving notification:", error);
    throw new Error("Error saving notification:", error);
  }
};

const fetchNotifications = async () => {
  try {
    const userRef = db
      .collection(DB_COLLECTIONS.NOTIFICATIONS)
      .doc(auth.currentUser.uid);

    const notifications = [];

    const userDoc = await userRef.get();

    if (userDoc.exists) {
      const userData = userDoc.data();

      for (const notifId of Object.keys(userData).sort((a, b) => b - a)) {
        const notifData = userData[notifId];
        notifData.id = notifId;

        notifications.push(notifData);
      }
    } else {
      console.log(
        "User document not found, initializing notifications collection for:",
        auth.currentUser.uid
      );
      await userRef.set({});
    }

    return notifications;
  } catch (error) {
    console.error("Error fetching notifications:", error);
    throw new Error("Error fetching notifications:", error);
  }
};

const checkMealPlanNotification = async (uid) => {
  const today = new Date();
  const dayOfWeek = today.getDay();
  const nearestSunday = new Date(today);
  nearestSunday.setDate(today.getDate() - (dayOfWeek === 0 ? 7 : dayOfWeek));

  const mealPlanRef = db.collection(DB_COLLECTIONS.MEAL_PLAN).doc(uid);

  const mealPlanDoc = await mealPlanRef.get();

  if (mealPlanDoc.exists) {
    const mealPlanData = mealPlanDoc.data();
    const lastGeneratedDate = new Date(mealPlanData.lastGeneratedDate);
    const sevenDaysLater = new Date(lastGeneratedDate);
    sevenDaysLater.setDate(sevenDaysLater.getDate() + 7);

    if (today >= sevenDaysLater) {
      return {
        title: "Weekly Update",
        body: "A new meal plan has been generated and the history has been reset.",
      };
    }
  }
};

const firebaseAPI = {
  initUponLogin,
  signUp,
  logIn,
  fetchIngredientsList,
  fetchToAddIngredients,
  fetchIngredientPicture,
  updateIngredientSupply,
  fetchRecipesList,
  fetchUserData,
  addInventory,
  cookRecipe,
  cookRecipeWithMissingIngredient,
  generateMealPlans,
  fetchGroceryList,
  updateGroceryItem,
  deleteGroceryItems,
  deleteAllGroceryItems,
  checkIngredientsWithQuantityOne,
  fetchHistory,
  updateHistory,
  isCookable,
  fetchMealPlanData,
  saveNotifications,
  fetchNotifications,
  checkMealPlanNotification,
  fetchExpiringIngredients,
};

export default firebaseAPI;
