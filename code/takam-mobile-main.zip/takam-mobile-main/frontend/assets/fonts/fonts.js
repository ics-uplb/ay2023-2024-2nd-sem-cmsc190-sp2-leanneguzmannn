export default {
  "LexendDeca-Black": require("../fonts/LexendDeca/LexendDeca-Black.ttf"),
  "LexendDeca-Bold": require("../fonts/LexendDeca/LexendDeca-Bold.ttf"),
  "LexendDeca-ExtraBold": require("../fonts/LexendDeca/LexendDeca-ExtraBold.ttf"),
  "LexendDeca-Light": require("../fonts/LexendDeca/LexendDeca-Light.ttf"),
  "LexendDeca-ExtraLight": require("../fonts/LexendDeca/LexendDeca-ExtraLight.ttf"),
  "LexendDeca-Medium": require("../fonts/LexendDeca/LexendDeca-Medium.ttf"),
  "LexendDeca-Regular": require("../fonts/LexendDeca/LexendDeca-Regular.ttf"),
  "LexendDeca-SemiBold": require("../fonts/LexendDeca/LexendDeca-SemiBold.ttf"),
  "LexendDeca-Thin": require("../fonts/LexendDeca/LexendDeca-Thin.ttf"),
};
