export default {
  //assets
  LOGO: require("./logo.png"),
  TITLE: require("./title.png"),
  LOADING: require("./loading.gif"),

  //splash screen
  IMAGE_3: require("./3.png"),
  IMAGE_4: require("./4.png"),
  IMAGE_5: require("./5.png"),
  IMAGE_6: require("./6.png"),
  IMAGE_7: require("./7.png"),

  //buttons
  SIGNIN1: require("./signin1.png"),
  SIGNIN2: require("./signin2.png"),
  SIGNUP1: require("./signup1.png"),
  SIGNUP2: require("./signup2.png"),
  HOME1: require("./home1.png"),
  HOME2: require("./home2.png"),
  SIGNOUT: require("./signout.png"),

  //homepage
  DAY: require("./morning.png"),
  NOON: require("./noon.png"),
  NIGHT: require("./night.png"),
  SLIDE1: require("./slide1.png"),
  SLIDE2: require("./slide2.png"),
  SLIDE3: require("./slide3.png"),
  SLIDE4: require("./slide4.png"),
  SLIDE5: require("./slide5.png"),
  SLIDE6: require("./slide6.png"),
  SLIDE7: require("./slide7.png"),
  SLIDE8: require("./slide8.png"),
  SLIDE9: require("./slide9.png"),

  //appbar icons
  MENU: require("./menu.png"),

  //recipe base
  INGREDIENTS: require("./Ingredients.png"),
  INSTRUCTIONS: require("./Instructions.png"),
  DIFFICULTY: require("./fire.png"),
  TIME: require("./time.png"),
  SERVING: require("./cutlery.png"),

  WIFI: require("./wifi.png"),
};
