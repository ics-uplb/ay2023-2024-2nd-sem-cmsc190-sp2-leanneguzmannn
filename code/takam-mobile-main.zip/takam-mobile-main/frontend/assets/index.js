import IMGS from './images/imgs';
import FONTS from './fonts/fonts';
import COLORS from './colors';

export {
  IMGS,
  FONTS,
  COLORS
}