import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Welcome = () => {
  return (
    <View>
      <Text style={styles.title}>Welcome to Takam App!</Text>
    </View>
  )
}

export default Welcome

const styles = StyleSheet.create({
  title: {
    color: "#FF0000",
    fontSize: 30,
  }
})