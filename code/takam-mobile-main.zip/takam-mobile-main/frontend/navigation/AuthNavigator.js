import React, { useContext, useEffect, useState } from "react";
import * as SecureStore from "expo-secure-store";

import ROUTES from "../../utilities/Routes";
import SplashScreen from "../screens/SplashScreen";
import Welcome from "../screens/Welcome";
import Signin from "../screens/Signin";
import Signup from "../screens/Signup";
import Loading from "./Loading";

import { createStackNavigator } from "@react-navigation/stack";

import UserSidebarNavigator from "./user-nav/UserSidebarNavigator";
import { UserContext } from "../../utilities/UserProvider";
import { auth, db } from "../../backend/firebase";
import { DB_COLLECTIONS } from "../../backend/constants";

const { Navigator, Screen } = createStackNavigator();

const Unauthorized = () => {
  return <Text>USER UNAUTHORIZED.</Text>;
};

const AuthNavigator = () => {
  const { user, setUser } = useContext(UserContext);

  const [isLoading, setIsLoading] = useState(true);

  // Check if the user is already authenticated
  const checkInitialAuth = async () => {
    const userAuthCredString = await SecureStore.getItemAsync("userAuthCred");

    if (userAuthCredString) {
      const userAuthCred = JSON.parse(userAuthCredString);

      await auth.signInWithEmailAndPassword(
        userAuthCred._email,
        userAuthCred._password
      );

      setUser(userAuthCred);
    }
  };

  useEffect(() => {
    if (user === null) {
      checkInitialAuth();
    }
  }, []);

  useEffect(() => {
    setIsLoading(true);

    if (user != null) {
      // Retrieve the user's userType from Firebase and set it in state
      const userRef = db.collection(DB_COLLECTIONS.USERS).doc(user.uid);
      userRef
        .get()
        .then((doc) => {
          if (!doc.exists) {
            console.log("User does not exist!");
          }
        })
        .finally(() => {
          setIsLoading(false);
        });
    } else {
      setIsLoading(false);
    }
  }, [user]);

  return (
    <Navigator
      initialRouteName={ROUTES.SPLASHSCREEN}
      screenOptions={{ headerShown: false }}
    >
      {!user ? (
        <>
          <Screen name={ROUTES.SPLASHSCREEN} component={SplashScreen} />
          <Screen name={ROUTES.WELCOME} component={Welcome} />
          <Screen name={ROUTES.SIGNIN} component={Signin} />
          <Screen name={ROUTES.SIGNUP} component={Signup} />
        </>
      ) : user ? (
        <>
          {isLoading ? (
            <Screen name={ROUTES.LOADING} component={Loading} />
          ) : (
            <Screen
              name={ROUTES.USER_SIDEBAR_NAVIGATOR}
              component={UserSidebarNavigator}
            />
          )}
        </>
      ) : isLoading ? (
        <Screen name={ROUTES.LOADING} component={Loading} />
      ) : (
        <Screen name={ROUTES.UNAUTHORIZED} component={Unauthorized} />
      )}
    </Navigator>
  );
};

export default AuthNavigator;
