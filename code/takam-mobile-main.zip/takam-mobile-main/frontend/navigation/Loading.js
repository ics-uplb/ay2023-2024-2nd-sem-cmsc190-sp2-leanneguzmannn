import React from "react";
import { View, Image, StyleSheet } from "react-native";

import { IMGS, COLORS } from "../assets";
import { verticalScale, horizontalScale } from "../screens/Scaling";

const Loading = (props) => {
  return (
    <View style={styles.container}>
      <Image source={IMGS.LOADING} style={styles.image} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.orange,
  },
  image: {
    flex: 1,
    width: horizontalScale(320),
    height: verticalScale(850),
  },
});

export default Loading;
