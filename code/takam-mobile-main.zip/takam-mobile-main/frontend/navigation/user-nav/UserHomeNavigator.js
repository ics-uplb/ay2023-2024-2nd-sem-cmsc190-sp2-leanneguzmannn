import React from "react";

import { StyleSheet, Image } from "react-native";

import { createStackNavigator } from "@react-navigation/stack";
import ROUTES from "../../../utilities/Routes";
import Home from "../../screens/user/Home";
import { IMGS } from "../../assets";
import CustomAppBar from "../../utilities/CustomAppBar";
import { useNavigation } from "@react-navigation/native";
import { verticalScale, horizontalScale } from "../../utilities/Scaling";

const { Navigator, Screen } = createStackNavigator();

const horizontalAnimation = {
  gestureDirection: "horizontal",
  cardStyleInterpolator: ({ current, layouts }) => {
    return {
      cardStyle: {
        transform: [
          {
            translateX: current.progress.interpolate({
              inputRange: [0, 1],
              outputRange: [layouts.screen.width, 0],
            }),
          },
        ],
      },
    };
  },
};

const UserHomeNavigator = () => {
  const navigation = useNavigation();

  return (
    <>
      <CustomAppBar
        navigation={navigation}
        titleImage={<Image source={IMGS.TITLE} style={styles.image} />}
      />

      <Navigator
        initialRouteName={ROUTES.USER_HOME}
        screenOptions={{ headerShown: false }}
      >
        <Screen
          name={ROUTES.USER_HOME}
          component={Home}
          options={horizontalAnimation}
        />
      </Navigator>
    </>
  );
};

export default UserHomeNavigator;

const styles = StyleSheet.create({
  image: {
    width: horizontalScale(120),
    height: verticalScale(30),
  },
});
