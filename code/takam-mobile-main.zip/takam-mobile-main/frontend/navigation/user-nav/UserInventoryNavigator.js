import React from "react";
import { StyleSheet, TouchableOpacity } from "react-native";
import { createStackNavigator } from "@react-navigation/stack";
import ROUTES from "../../../utilities/Routes";
import CustomAppBar from "../../utilities/CustomAppBar";
import { useNavigation } from "@react-navigation/native";
import Inventory from "../../screens/user/Inventory";
import AddInventory from "../../screens/user/AddInventory";
import { Ionicons } from "@expo/vector-icons";
import {
  horizontalScale,
  moderateScale,
  verticalScale,
} from "../../utilities/Scaling";
import { COLORS } from "../../assets";
const { Navigator, Screen } = createStackNavigator();

const horizontalAnimation = {
  gestureDirection: "horizontal",
  cardStyleInterpolator: ({ current, layouts }) => {
    return {
      cardStyle: {
        transform: [
          {
            translateX: current.progress.interpolate({
              inputRange: [0, 1],
              outputRange: [layouts.screen.width, 0],
            }),
          },
        ],
      },
    };
  },
};

const UserInventoryNavigator = () => {
  const navigation = useNavigation();

  return (
    <>
      <CustomAppBar
        navigation={navigation}
        name={"INVENTORY"}
        trailingIcon={
          <TouchableOpacity
            onPress={() => {
              navigation.navigate(ROUTES.USER_ADD_INVENTORY);
            }}
          >
            <Ionicons
              name="ios-archive"
              size={moderateScale(25)}
              color={COLORS.darkBrown}
              style={styles.trail}
            />
          </TouchableOpacity>
        }
      />

      <Navigator
        initialRouteName={ROUTES.USER_INVENTORY}
        screenOptions={{ headerShown: false }}
      >
        <Screen
          name={ROUTES.USER_INVENTORY}
          component={Inventory}
          options={horizontalAnimation}
        />

        <Screen
          name={ROUTES.USER_ADD_INVENTORY}
          component={AddInventory}
          options={horizontalAnimation}
        />
      </Navigator>
    </>
  );
};

export default UserInventoryNavigator;

const styles = StyleSheet.create({
  trail: {
    right: horizontalScale(8),
    top: verticalScale(4),
  },
});
