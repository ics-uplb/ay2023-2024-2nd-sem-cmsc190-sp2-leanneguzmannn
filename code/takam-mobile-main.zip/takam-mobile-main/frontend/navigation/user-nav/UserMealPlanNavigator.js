import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import ROUTES from "../../../utilities/Routes";
import CustomAppBar from "../../utilities/CustomAppBar";
import { useNavigation } from "@react-navigation/native";
import MealPlan from "../../screens/user/MealPlan";
const { Navigator, Screen } = createStackNavigator();
import RecipePage from "../../screens/user/RecipePage";
import RecipeIngredients from "../../screens/user/RecipeIngredients";
import RecipeInstructions from "../../screens/user/RecipeInstructions";

const horizontalAnimation = {
  gestureDirection: "horizontal",
  cardStyleInterpolator: ({ current, layouts }) => {
    return {
      cardStyle: {
        transform: [
          {
            translateX: current.progress.interpolate({
              inputRange: [0, 1],
              outputRange: [layouts.screen.width, 0],
            }),
          },
        ],
      },
    };
  },
};

const UserMealPlanNavigator = () => {
  const navigation = useNavigation();

  return (
    <>
      <CustomAppBar navigation={navigation} name={"MEAL PLAN"} />

      <Navigator
        initialRouteName={ROUTES.USER_MEALPLAN}
        screenOptions={{ headerShown: false }}
      >
        <Screen
          name={ROUTES.USER_MEALPLAN}
          component={MealPlan}
          options={horizontalAnimation}
        />

        <Screen name={ROUTES.USER_RECIPEPAGE} component={RecipePage} />
        <Screen name={ROUTES.USER_INGREDIENTS} component={RecipeIngredients} />
        <Screen
          name={ROUTES.USER_INSTRUCTIONS}
          component={RecipeInstructions}
        />
      </Navigator>
    </>
  );
};

export default UserMealPlanNavigator;
