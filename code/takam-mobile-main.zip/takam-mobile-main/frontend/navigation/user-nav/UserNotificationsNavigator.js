import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import ROUTES from "../../../utilities/Routes";
import CustomAppBar from "../../utilities/CustomAppBar";
import { useNavigation } from "@react-navigation/native";
import Notifications from "../../screens/user/Notifications";
const { Navigator, Screen } = createStackNavigator();

const horizontalAnimation = {
  gestureDirection: "horizontal",
  cardStyleInterpolator: ({ current, layouts }) => {
    return {
      cardStyle: {
        transform: [
          {
            translateX: current.progress.interpolate({
              inputRange: [0, 1],
              outputRange: [layouts.screen.width, 0],
            }),
          },
        ],
      },
    };
  },
};

const UserNotificationsNavigator = () => {
  const navigation = useNavigation();

  return (
    <>
      <CustomAppBar navigation={navigation} name={"NOTIFICATION"} />

      <Navigator
        initialRouteName={ROUTES.USER_NOTIFICATIONS}
        screenOptions={{ headerShown: false }}
      >
        <Screen
          name={ROUTES.USER_NOTIFICATIONS}
          component={Notifications}
          options={horizontalAnimation}
        />
      </Navigator>
    </>
  );
};

export default UserNotificationsNavigator;
