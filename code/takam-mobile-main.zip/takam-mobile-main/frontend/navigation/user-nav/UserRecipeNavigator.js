import React from "react";
import { createStackNavigator } from "@react-navigation/stack";
import ROUTES from "../../../utilities/Routes";
import CustomAppBar from "../../utilities/CustomAppBar";
import { useNavigation } from "@react-navigation/native";
import Recipe from "../../screens/user/Recipe";
import RecipePage from "../../screens/user/RecipePage";
import RecipeIngredients from "../../screens/user/RecipeIngredients";
import RecipeInstructions from "../../screens/user/RecipeInstructions";
const { Navigator, Screen } = createStackNavigator();

const horizontalAnimation = {
  gestureDirection: "horizontal",
  cardStyleInterpolator: ({ current, layouts }) => {
    return {
      cardStyle: {
        transform: [
          {
            translateX: current.progress.interpolate({
              inputRange: [0, 1],
              outputRange: [layouts.screen.width, 0],
            }),
          },
        ],
      },
    };
  },
};

const UserRecipeNavigator = () => {
  const navigation = useNavigation();

  return (
    <>
      <CustomAppBar navigation={navigation} name={"RECIPE"} />

      <Navigator
        initialRouteName={ROUTES.USER_RECIPE}
        screenOptions={{ headerShown: false }}
      >
        <Screen
          name={ROUTES.USER_RECIPE}
          component={Recipe}
          options={horizontalAnimation}
          initialParams={{ selectedButton: null }}
        />

        <Screen name={ROUTES.USER_RECIPEPAGE} component={RecipePage} />
        <Screen name={ROUTES.USER_INGREDIENTS} component={RecipeIngredients} />
        <Screen
          name={ROUTES.USER_INSTRUCTIONS}
          component={RecipeInstructions}
        />
      </Navigator>
    </>
  );
};

export default UserRecipeNavigator;
