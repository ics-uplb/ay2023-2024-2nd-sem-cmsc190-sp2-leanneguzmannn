import {
  Ionicons,
  MaterialIcons,
  MaterialCommunityIcons,
  FontAwesome5,
} from "@expo/vector-icons";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { useFonts } from "expo-font";
import * as SplashScreen from "expo-splash-screen";
import React, { useCallback, useEffect } from "react";
import { StyleSheet } from "react-native";
import CustomDrawer from "../../utilities/CustomDrawer";
import { FONTS, COLORS } from "../../assets";
import ROUTES from "../../../utilities/Routes";
import { horizontalScale, moderateScale } from "../../utilities/Scaling";
import UserHomeNavigator from "./UserHomeNavigator";
import UserInventoryNavigator from "./UserInventoryNavigator";
import UserRecipeNavigator from "./UserRecipeNavigator";
import UserMealPlanNavigator from "./UserMealPlanNavigator";
import UserGroceryNavigator from "./UserGroceryNavigator";
import UserHistoryNavigator from "./UserHistoryNavigator";
import UserNotificationsNavigator from "./UserNotificationsNavigator";

const { Navigator, Screen } = createDrawerNavigator();

const UserSidebarNavigator = (props) => {
  const { navigation } = props;
  const [fontsLoaded] = useFonts(FONTS);

  useEffect(() => {
    async function prepare() {
      await SplashScreen.preventAutoHideAsync();
    }
    prepare();
  }, []);

  const onLayoutRootView = useCallback(async () => {
    if (fontsLoaded) {
      await SplashScreen.hideAsync();
    }
  }, [fontsLoaded]);

  if (!fontsLoaded) {
    return null;
  }

  return (
    <Navigator
      drawerContent={(props) => <CustomDrawer {...props} />}
      screenOptions={{
        headerShown: false,
        unmountOnBlur: true,
        swipeEnabled: true,
        drawerActiveBackgroundColor: COLORS.darkBrown,
        drawerActiveTintColor: COLORS.white,
        drawerInactiveTintColor: COLORS.black,
        drawerLabelStyle: styles.labelStyle,
      }}
      onLayoutRootView={onLayoutRootView}
    >
      <Screen
        name={ROUTES.USER_HOME_NAVIGATOR}
        component={UserHomeNavigator}
        options={{
          title: "Home",
          drawerIcon: ({ color }) => (
            <Ionicons
              name="home"
              size={moderateScale(22)}
              color={COLORS.darkCream}
            />
          ),
        }}
      />

      <Screen
        name={ROUTES.USER_INVENTORY_NAVIGATOR}
        component={UserInventoryNavigator}
        options={{
          title: "Inventory",
          drawerIcon: ({ color }) => (
            <MaterialIcons
              name="inventory"
              size={moderateScale(22)}
              color={COLORS.darkCream}
            />
          ),
        }}
      />

      <Screen
        name={ROUTES.USER_RECIPE_NAVIGATOR}
        component={UserRecipeNavigator}
        options={{
          title: "Recipe",
          drawerIcon: ({ color }) => (
            <MaterialIcons
              name="menu-book"
              size={moderateScale(22)}
              color={COLORS.darkCream}
            />
          ),
        }}
      />

      <Screen
        name={ROUTES.USER_MEALPLAN_NAVIGATOR}
        component={UserMealPlanNavigator}
        options={{
          title: "Meal Plan",
          drawerIcon: ({ color }) => (
            <MaterialCommunityIcons
              name="food-turkey"
              size={moderateScale(22)}
              color={COLORS.darkCream}
            />
          ),
        }}
      />

      <Screen
        name={ROUTES.USER_GROCERY_NAVIGATOR}
        component={UserGroceryNavigator}
        options={{
          title: "Grocery List",
          drawerIcon: ({ color }) => (
            <MaterialIcons
              name="local-grocery-store"
              size={moderateScale(22)}
              color={COLORS.darkCream}
            />
          ),
        }}
      />

      <Screen
        name={ROUTES.USER_HISTORY_NAVIGATOR}
        component={UserHistoryNavigator}
        options={{
          title: "History",
          drawerIcon: ({ color }) => (
            <FontAwesome5
              name="history"
              size={moderateScale(22)}
              color={COLORS.darkCream}
            />
          ),
        }}
      />

      <Screen
        name={ROUTES.USER_NOTIFICATIONS_NAVIGATOR}
        component={UserNotificationsNavigator}
        options={{
          title: "Notifications",
          drawerIcon: ({ color }) => (
            <MaterialIcons
              name="notifications"
              size={moderateScale(22)}
              color={COLORS.darkCream}
            />
          ),
        }}
      />
    </Navigator>
  );
};

export default UserSidebarNavigator;

const styles = StyleSheet.create({
  labelStyle: {
    marginLeft: horizontalScale(-15),
    fontFamily: "LexendDeca-SemiBold",
    fontStyle: "normal",
    fontWeight: 400,
    fontSize: moderateScale(18),
    color: COLORS.cream,
  },
});
