import { Ionicons } from "@expo/vector-icons";
import { useFonts } from "expo-font";
import * as SplashScreen from "expo-splash-screen";
import React, { useCallback, useContext, useEffect, useState } from "react";
import {
  Image,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import ROUTES from "../../utilities/Routes";
import { COLORS, FONTS, IMGS } from "../assets";
import CustomField from "../utilities/CustomField";
import { horizontalScale, moderateScale, verticalScale } from "./Scaling";

import { BackHandler } from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import firebaseAPI from "../../backend/firebase-api";
import { UserContext } from "../../utilities/UserProvider";
import CustomAlert from "../utilities/CustomAlert";

const Signin = (props) => {
  const { navigation } = props;

  const { user, setUser } = useContext(UserContext);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [emailError, setEmailError] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const [fontsLoaded] = useFonts(FONTS);

  const [showAlert, setShowAlert] = useState(false);
  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");

  useEffect(() => {
    async function prepare() {
      await SplashScreen.preventAutoHideAsync();
    }
    prepare();

    const handleBackPress = () => {
      navigation.goBack();
      return true;
    };

    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () => {
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
    };
  }, []);

  const handleLogIn = async () => {
    try {
      await firebaseAPI.logIn(email, password, setUser);
    } catch (error) {
      console.log("Login Error: ", error.message);
      setTitle("Login Error");
      setSubtitle(error.message);
      setShowAlert(true);
    }
  };

  function isEnabledSignIn() {
    return email != "" && password != "";
  }

  const handleHomeButtonPress = () => {
    navigation.navigate(ROUTES.WELCOME);
  };

  const handleSignUpButtonPress = () => {
    navigation.navigate(ROUTES.SIGNUP);
  };

  useEffect(() => {
    async function prepare() {
      await SplashScreen.preventAutoHideAsync();
    }
    prepare();
  });

  const onLayoutRootView = useCallback(async () => {
    if (fontsLoaded) {
      await SplashScreen.hideAsync();
    }
  }, [fontsLoaded]);

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View style={styles.container} onLayout={onLayoutRootView}>
      <KeyboardAwareScrollView
        enableOnAndroid={true}
        showsVerticalScrollIndicator={false}
        style={{ width: "100%" }}
        contentContainerStyle={{
          flexGrow: 1,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <View style={styles.smallbtn}>
          <TouchableOpacity onPress={handleHomeButtonPress}>
            <Image source={IMGS.HOME1} style={styles.smallbutton} />
          </TouchableOpacity>
        </View>
        <Image source={IMGS.LOGO} style={styles.logo} />
        <View style={styles.inputSection}>
          <CustomField
            label="Email Address"
            defaultValue={email}
            keyboardType="email-address"
            autoCompleteType="email"
            placeholder="Enter Email"
            inputStyle={styles.inputStyle}
            labelStyle={styles.labelStyle}
            onChangeText={(text) => setEmail(text)}
            boxStyle={{
              elevation: 3,
              shadowColor: "#000",
              shadowOffset: {
                width: 0,
                height: verticalScale(2),
              },
              shadowOpacity: 0.17,
              shadowRadius: 2.54,
              borderLeftWidth: moderateScale(3),
              borderRightWidth: moderateScale(3),
              borderBottomWidth: moderateScale(6),
              borderColor: COLORS.darkBrown,
            }}
            prependComponent={
              <View
                style={{
                  justifyContent: "center",
                }}
              >
                <Ionicons
                  name={"mail"}
                  size={moderateScale(20)}
                  color={COLORS.darkCream}
                />
              </View>
            }
          />
          <CustomField
            label="Password"
            defaultValue={password}
            secureTextEntry={!showPassword}
            autoCompleteType="password"
            placeholder="Enter Password"
            inputStyle={styles.inputStyle}
            labelStyle={styles.labelStyle}
            onChangeText={(text) => setPassword(text)}
            boxStyle={{
              elevation: 3,
              shadowColor: "#000",
              shadowOffset: {
                width: 0,
                height: verticalScale(2),
              },
              shadowOpacity: 0.17,
              shadowRadius: 2.54,
              borderLeftWidth: moderateScale(3),
              borderRightWidth: moderateScale(3),
              borderBottomWidth: moderateScale(6),
              borderColor: COLORS.darkBrown,
            }}
            prependComponent={
              <View
                style={{
                  justifyContent: "center",
                }}
              >
                <Ionicons
                  name={"lock-closed"}
                  size={moderateScale(20)}
                  color={COLORS.darkCream}
                />
              </View>
            }
            appendComponent={
              <Pressable onPress={() => setShowPassword(!showPassword)}>
                <Ionicons
                  name={showPassword ? "eye-off" : "eye"}
                  size={moderateScale(20)}
                  color={showPassword ? COLORS.darkCream : COLORS.darkCream}
                />
              </Pressable>
            }
          />
        </View>
        <View style={styles.bottomctn}>
          <TouchableOpacity
            disabled={isEnabledSignIn() ? false : true}
            activeOpacity={0.6}
            onPress={handleLogIn}
          >
            <Image source={IMGS.SIGNIN2} style={styles.button} />
          </TouchableOpacity>
          <View style={styles.bottomtxt}>
            <Text style={styles.textStyle}> Don’t have an account? </Text>
            <TouchableOpacity onPress={handleSignUpButtonPress}>
              <Text style={styles.textStyleBold}> Sign up </Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAwareScrollView>
      {showAlert ? (
        <CustomAlert
          title={title}
          subtitle={subtitle}
          animationType="fade"
          transparent={true}
          visible={showAlert}
          cancelEnabled={false}
          onRequestClose={() => {
            setShowAlert(false);
          }}
          onConfirm={() => setShowAlert(false)}
        />
      ) : (
        <></>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.orange,
  },
  smallbutton: {
    width: horizontalScale(140),
    height: verticalScale(30),
  },
  smallbtn: {
    right: horizontalScale(80),
    bottom: verticalScale(60),
  },
  logo: {
    width: horizontalScale(200),
    height: verticalScale(160),
    bottom: verticalScale(20),
  },
  labelStyle: {
    fontFamily: "LexendDeca-Bold",
    fontSize: moderateScale(16),
    color: COLORS.darkCream,
    paddingBottom: verticalScale(5),
  },
  inputSection: {
    height: verticalScale(200),
    alignItems: "center",
    justifyContent: "space-evenly",
  },
  inputStyle: {
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(15),
    color: COLORS.darkCream,
    paddingHorizontal: horizontalScale(5),
  },
  button: {
    width: horizontalScale(240),
    height: verticalScale(50),
  },
  bottomctn: {
    justifyContent: "center",
    alignItems: "center",
    top: verticalScale(50),
  },
  bottomtxt: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  textStyle: {
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(12),
    color: COLORS.darkCream,
    paddingTop: verticalScale(5),
  },
  textStyleBold: {
    fontFamily: "LexendDeca-Bold",
    fontSize: moderateScale(12),
    color: COLORS.darkCream,
    paddingTop: verticalScale(5),
  },
});

export default Signin;
