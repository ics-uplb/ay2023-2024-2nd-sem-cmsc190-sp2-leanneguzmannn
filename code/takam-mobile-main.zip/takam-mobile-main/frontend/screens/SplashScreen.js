import React, { useState, useEffect } from 'react';
import { View, Image, StyleSheet} from 'react-native';
import { horizontalScale, verticalScale } from './Scaling';

import { IMGS, COLORS } from '../assets';
import ROUTES from '../../utilities/Routes';

const SplashScreen = (props) => {
  const { navigation } = props;
  const imageSources = [
    IMGS.IMAGE_3,
    IMGS.IMAGE_4,
    IMGS.IMAGE_5,
    IMGS.IMAGE_6,
    IMGS.IMAGE_7,
  ];

  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {

    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % imageSources.length);
    }, 600); 

    const timeout = setTimeout(() => {
      clearInterval(interval);

      navigation.navigate(ROUTES.WELCOME);

    }, 3000);

    // Clean up the interval to prevent memory leaks
    return () => clearInterval(timeout);
  }, []);

  return (
    <View style={styles.container}>
      <Image
        source={imageSources[currentImageIndex]}
        style={styles.image}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.orange
  },
  image: {
    flex: 1,
    width: horizontalScale(320),
    height: verticalScale(850),
  },
});

export default SplashScreen;
