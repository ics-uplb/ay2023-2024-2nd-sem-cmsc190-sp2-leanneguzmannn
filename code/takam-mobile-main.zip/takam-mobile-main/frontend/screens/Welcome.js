import React, { useState, useEffect, useCallback } from "react";
import { View, Image, StyleSheet, TouchableOpacity, Text } from "react-native";
import { useFonts } from "expo-font";
import * as SplashScreen from "expo-splash-screen";

import { horizontalScale, verticalScale, moderateScale } from "./Scaling";
import { FONTS, IMGS, COLORS } from "../assets";
import ROUTES from "../../utilities/Routes";

const Welcome = (props) => {
  const { navigation } = props;
  const [fontsLoaded] = useFonts(FONTS);

  const handleSignInButtonPress = () => {
    navigation.navigate(ROUTES.SIGNIN);
  };

  const handleSignUpButtonPress = () => {
    navigation.navigate(ROUTES.SIGNUP);
  };

  useEffect(() => {
    async function prepare() {
      await SplashScreen.preventAutoHideAsync();
    }
    prepare();
  });

  const onLayoutRootView = useCallback(async () => {
    if (fontsLoaded) {
      await SplashScreen.hideAsync();
    }
  }, [fontsLoaded]);

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View style={styles.container} onLayout={onLayoutRootView}>
      <View style={styles.container}>
        <View style={styles.logo_container}>
          <Image source={IMGS.LOGO} style={styles.logo} />
          <Text style={styles.tagline}>Takam na takam ka na ba?</Text>
        </View>
        <View style={styles.btn_container}>
          <TouchableOpacity onPress={handleSignInButtonPress}>
            <Image source={IMGS.SIGNIN1} style={styles.button} />
          </TouchableOpacity>
          <TouchableOpacity onPress={handleSignUpButtonPress}>
            <Image source={IMGS.SIGNUP1} style={styles.button} />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.orange,
  },
  logo_container: {
    justifyContent: "center",
    alignItems: "center",
    marginBottom: verticalScale(100),
  },
  logo: {
    width: horizontalScale(250),
    height: verticalScale(210),
    top: 10,
    bottom: 0,
  },
  tagline: {
    fontFamily: "LexendDeca-Bold",
    color: COLORS.darkCream,
  },
  btn_container: {
    height: verticalScale(170),
    alignItems: "center",
    justifyContent: "space-evenly",
    paddingBottom: verticalScale(50),
    position: "absolute",
    bottom: verticalScale(30),
  },
  button: {
    width: horizontalScale(240),
    height: verticalScale(50),
  },
});

export default Welcome;
