import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  BackHandler,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { KeyboardAwareFlatList } from "react-native-keyboard-aware-scroll-view";
import { auth } from "../../../backend/firebase";
import firebaseAPI from "../../../backend/firebase-api";
import ROUTES from "../../../utilities/Routes";
import { COLORS } from "../../assets";
import CustomAlert from "../../utilities/CustomAlert";
import NetworkStatus from "../../utilities/NetworkStatus";
import { horizontalScale, moderateScale, verticalScale } from "../Scaling";

const AddInventory = (props) => {
  const { navigation } = props;

  const [isLoading, setIsLoading] = useState(true);
  const [allIngredients, setAllIngredients] = useState([]);

  const [showAlert, setShowAlert] = useState(false);
  const [showAlert2, setShowAlert2] = useState(false);

  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");

  const [ingredientQuantities, setIngredientQuantities] = useState({});

  const handleIngredientsList = async () => {
    try {
      setAllIngredients(
        await firebaseAPI.fetchToAddIngredients(auth.currentUser.uid)
      );
    } catch (error) {
      console.log("Error fetching ingredients: ", error.message);
      setTitle("Error fetching ingredients");
      setSubtitle(error.message);
      setShowAlert(true);
    }
  };

  const renderItem = ({ item }) => {
    const quantity = ingredientQuantities[item.id] || "";

    return (
      <View style={styles.itemContainer}>
        <Text style={styles.itemName}>{item.name}</Text>
        <TextInput
          style={styles.quantityInput}
          value={quantity}
          onChangeText={(text) => handleQuantityChange(item.id, text)}
          keyboardType="numeric"
          placeholder="Quantity"
          placeholderTextColor="#999"
        />

        <Text style={styles.measure}>{item.measuredBy}</Text>
      </View>
    );
  };

  const handleQuantityChange = (ingredientId, text) => {
    setIngredientQuantities((prevState) => ({
      ...prevState,
      [ingredientId]: text,
    }));
  };

  const handleAddInventory = async (ingredientQuantities) => {
    try {
      await firebaseAPI
        .addInventory(ingredientQuantities)
        .then(() =>
          navigation.navigate(ROUTES.USER_INVENTORY, { refresh: true })
        );
    } catch (error) {
      console.log("Error adding ingredients: ", error.message);
      setTitle("Error adding ingredients");
      setSubtitle(error.message);
      setShowAlert2(true);
    }
  };

  useEffect(() => {
    // Function to fetch the ingredients
    const fetchIngredientsList = () => {
      setIsLoading(true);

      handleIngredientsList()
        .then(() => {
          setIsLoading(false);
        })
        .catch((error) => {
          console.log(error.message);
          setIsLoading(false);
        });
    };

    fetchIngredientsList();

    const handleBackPress = () => {
      navigation.goBack();
      return true;
    };

    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () => {
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
    };
  }, []);

  return (
    <View style={styles.container}>
      {isLoading ? (
        <View style={styles.loadingIndicator}>
          <ActivityIndicator size="large" color={COLORS.lightOrange} />
        </View>
      ) : (
        <KeyboardAwareFlatList
          enableOnAndroid={true}
          data={allIngredients}
          renderItem={renderItem}
          keyExtractor={(_, index) => index.toString()}
          showsVerticalScrollIndicator={false}
          ListFooterComponent={
            // Move your button to ListFooterComponent
            <TouchableOpacity
              style={styles.button}
              onPress={() => handleAddInventory(ingredientQuantities)}
            >
              <Text style={styles.buttonText}>Add Inventory</Text>
            </TouchableOpacity>
          }
          ListFooterComponentStyle={{
            alignItems: "center",
          }}
        />
      )}
      {showAlert ? (
        <CustomAlert
          title={title}
          subtitle={subtitle}
          animationType="fade"
          transparent={true}
          visible={showAlert}
          cancelEnabled={false}
          onRequestClose={() => {
            setShowAlert(false);
          }}
          onConfirm={() => setShowAlert(false)}
        />
      ) : (
        <></>
      )}
      {showAlert2 ? (
        <CustomAlert
          title={title}
          subtitle={subtitle}
          animationType="fade"
          transparent={true}
          visible={showAlert2}
          cancelEnabled={false}
          onRequestClose={() => {
            setShowAlert2(false);
          }}
          onConfirm={() => setShowAlert2(false)}
        />
      ) : (
        <></>
      )}
      <NetworkStatus />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.cream,
    justifyContent: "center",
    alignItems: "center",
  },
  itemContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: verticalScale(5),
    borderBottomWidth: moderateScale(2),
    borderBottomColor: COLORS.darkBrown,
    padding: moderateScale(3),
  },
  itemName: {
    width: "50%",
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(13),
    color: COLORS.orange,
    flexWrap: "wrap",
  },
  measure: {
    width: "20%",
    fontSize: moderateScale(13),
    fontFamily: "LexendDeca-Regular",
    color: COLORS.brown,
  },
  quantityInput: {
    width: "20%",
    height: verticalScale(40),
    borderWidth: moderateScale(1),
    borderColor: "#ccc",
    paddingHorizontal: horizontalScale(5),
    borderRadius: moderateScale(5),
    marginRight: "5%",
    fontFamily: "LexendDeca-Regular",
    fontSize: moderateScale(13),
    color: COLORS.darkBrown,
  },
  buttonContainer: {
    width: "70%",
    justifyContent: "flex-end",
    margin: moderateScale(10),
    backgroundColor: "transparent",
  },
  button: {
    backgroundColor: COLORS.green,
    paddingVertical: verticalScale(12),
    paddingHorizontal: horizontalScale(!0),
    borderRadius: moderateScale(5),
    alignItems: "center",
    width: "30%",
    justifyContent: "center",
    alignContent: "center",
    marginVertical: verticalScale(10),
  },
  buttonText: {
    color: COLORS.cream,
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(12),
    alignSelf: "center",
    justifyContent: "center",
    flexWrap: "wrap",
  },
});

export default AddInventory;
