import React, { useEffect, useState } from "react";
import {
  BackHandler,
  FlatList,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import firebaseAPI from "../../../backend/firebase-api";
import { COLORS } from "../../assets";
import NetworkStatus from "../../utilities/NetworkStatus";
import { horizontalScale, moderateScale, verticalScale } from "../Scaling";

const Grocery = (props) => {
  const { navigation } = props;

  const [isLoading, setIsLoading] = useState(true);
  const [groceryList, setGroceryList] = useState([]);
  const [checkedItems, setCheckedItems] = useState([]);

  useEffect(() => {
    const fetchGroceryList = async () => {
      setIsLoading(true);

      try {
        const groceriesData = await firebaseAPI.fetchGroceryList();
        setGroceryList(groceriesData);
      } catch (error) {
        console.error("Error fetching grocery list:", error);
      }

      setIsLoading(false);
    };

    fetchGroceryList();

    const handleBackPress = () => {
      navigation.goBack();
      return true;
    };

    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () => {
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
    };
  }, []);

  const handleAddItem = () => {
    const newId =
      groceryList.length > 0
        ? Number(groceryList[groceryList.length - 1].id) + 1
        : 1;
    setGroceryList([...groceryList, { id: newId, name: "" }]);
  };

  const handleItemChange = async (text, index) => {
    // Check if the text already exists in the grocery list
    const itemExists = groceryList.some(
      (item, itemIndex) => item.name === text && itemIndex !== index
    );

    // If the item exists, clear the text input
    if (itemExists) {
      const newItems = [...groceryList];
      newItems[index].name = "";
      setGroceryList(newItems);

      // Delete the checked items from the database
      await firebaseAPI.deleteGroceryItems([newItems[index].id]);
    } else {
      // Otherwise, update the item
      const newItems = [...groceryList];
      newItems[index].name = text;
      setGroceryList(newItems);

      // Update the item in the database
      await firebaseAPI.updateGroceryItem(newItems[index].id, { name: text });
    }
  };

  const handleCheckboxToggle = (index) => {
    const newItems = [...groceryList];
    const selectedItem = newItems[index];

    // Check if the selected item is already in the checkedItems array
    const isChecked = checkedItems.includes(selectedItem);

    // If the item is already checked, remove it; otherwise, add it
    if (isChecked) {
      setCheckedItems(checkedItems.filter((item) => item !== selectedItem));
    } else {
      setCheckedItems([...checkedItems, selectedItem]);
    }
  };

  const handleClearItems = async () => {
    await firebaseAPI.deleteAllGroceryItems();
    setGroceryList([]);
  };

  const handleDeleteCheckedItems = async () => {
    try {
      // Collect the IDs of all checked items
      const checkedItemIds = checkedItems.map((item) => item.id);

      // Delete the checked items from the database
      await firebaseAPI.deleteGroceryItems(checkedItemIds);

      // Remove the checked items from the local state
      const newItems = groceryList.filter(
        (item) => !checkedItemIds.includes(item.id)
      );
      setGroceryList(newItems);
    } catch (error) {
      console.error("Error deleting checked items:", error);
      // Handle error as needed
    }
  };

  const renderItem = ({ item, index }) => {
    return (
      <View style={styles.row}>
        <TouchableOpacity onPress={() => handleCheckboxToggle(index)}>
          <View
            style={[
              styles.checkbox,
              checkedItems.includes(item) && styles.checkedCheckbox,
            ]}
          />
        </TouchableOpacity>
        <TextInput
          style={styles.itemInput}
          value={item.name}
          onChangeText={(text) => handleItemChange(text, index)}
          placeholder="Enter item"
        />
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={groceryList}
        renderItem={renderItem}
        ListEmptyComponent={
          <Text style={styles.title}>No Items Listed</Text>
        }
        keyExtractor={(item) => item.id.toString()}
      />
      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={[styles.button, { marginRight: 10 }]}
          onPress={handleAddItem}
        >
          <Text style={styles.buttonText}>Add Item</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.button,
            { backgroundColor: COLORS.darkBrown, marginRight: 10 },
          ]}
          onPress={handleDeleteCheckedItems}
        >
          <Text style={styles.buttonText}>Delete Item</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, { backgroundColor: COLORS.red }]}
          onPress={handleClearItems}
        >
          <Text style={styles.buttonText}>Clear List</Text>
        </TouchableOpacity>
      </View>
      <NetworkStatus />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: moderateScale(20),
    backgroundColor: COLORS.cream,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: verticalScale(10),
  },
  checkbox: {
    width: horizontalScale(20),
    height: verticalScale(20),
    borderWidth: moderateScale(2),
    borderColor: COLORS.lightOrange,
    marginRight: horizontalScale(10),
    borderRadius: moderateScale(2),
  },
  checkedCheckbox: {
    backgroundColor: COLORS.lightOrange,
  },
  itemInput: {
    color: COLORS.lightOrange,
    fontFamily: "LexendDeca-Medium",
    flex: 1,
    borderWidth: moderateScale(4),
    borderColor: COLORS.lightOrange,
    padding: moderateScale(10),
    borderRadius: moderateScale(10),
  },
  buttonContainer: {
    flexDirection: "row",
    marginTop: verticalScale(20),
  },
  button: {
    backgroundColor: COLORS.green,
    paddingVertical: verticalScale(10),
    paddingHorizontal: horizontalScale(20),
    borderRadius: moderateScale(5),
    alignItems: "center",
    width: "30%",
    justifyContent: "center",
    alignContent: "center",
    flexWrap: "wrap",
    textAlign: "center",
  },
  buttonText: {
    color: COLORS.cream,
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(12),
    alignSelf: "center",
    textAlign: "center",
  },
  title: {
    fontSize: moderateScale(20),
    flexWrap: "wrap",
    fontFamily: "LexendDeca-Medium",
    color: "#888",
    marginBottom: moderateScale(20),
    alignSelf: "center",
  },
});

export default Grocery;
