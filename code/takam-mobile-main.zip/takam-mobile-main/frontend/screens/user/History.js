import React, { useEffect, useState } from "react";
import {
  BackHandler,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { auth } from "../../../backend/firebase";
import firebaseAPI from "../../../backend/firebase-api";
import { COLORS } from "../../assets";
import NetworkStatus from "../../utilities/NetworkStatus";
import { horizontalScale, moderateScale, verticalScale } from "../Scaling";

const History = (props) => {
  const { navigation } = props;
  const [editable, setEditable] = useState(false);

  const daysOfWeek = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];

  const [historyData, setHistoryData] = useState({
    MON: { lunch: "", dinner: "" },
    TUE: { lunch: "", dinner: "" },
    WED: { lunch: "", dinner: "" },
    THU: { lunch: "", dinner: "" },
    FRI: { lunch: "", dinner: "" },
    SAT: { lunch: "", dinner: "" },
    SUN: { lunch: "", dinner: "" },
  });

  const handleLunchChange = (text, day) => {
    setHistoryData((prevData) => ({
      ...prevData,
      [day]: {
        ...prevData[day],
        lunch: text,
      },
    }));
  };

  const handleDinnerChange = (text, day) => {
    setHistoryData((prevData) => ({
      ...prevData,
      [day]: {
        ...prevData[day],
        dinner: text,
      },
    }));
  };

  const toggleEditable = async () => {
    if (editable) {
      // Save the updated history data to the database when done editing
      try {
        await firebaseAPI.updateHistory(auth.currentUser.uid, historyData);
      } catch (error) {
        console.error("Error updating history data:", error);
      }
    }
    setEditable(!editable);
  };

  useEffect(() => {
    const fetchHistoryData = async () => {
      try {
        const data = await firebaseAPI.fetchHistory(auth.currentUser.uid);
        setHistoryData(data);
      } catch (error) {
        console.error("Error fetching history data:", error);
      }
    };

    fetchHistoryData();

    const handleBackPress = () => {
      navigation.goBack();
      return true;
    };

    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () => {
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
    };
  }, []);

  return (
    <View style={styles.container}>
      <KeyboardAwareScrollView
        enableOnAndroid={true}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.screen}>
          <View style={styles.header}>
            <View style={styles.headerCell}>
              <Text style={styles.headerText}>lunch</Text>
            </View>
            <View style={styles.headerCell}>
              <Text style={styles.headerText}>dinner</Text>
            </View>
          </View>

          {daysOfWeek.map((item, index) => (
            <View style={styles.row} key={index}>
              <View style={styles.dayCell}>
                <Text style={styles.dayText}>{item}</Text>
              </View>
              <TextInput
                style={[
                  styles.cell,
                  editable ? styles.editableInput : styles.nonEditableInput,
                ]}
                value={historyData[item].lunch}
                onChangeText={(text) => handleLunchChange(text, item)}
                editable={editable}
                multiline={true}
              />
              <TextInput
                style={[
                  styles.cell,
                  editable ? styles.editableInput : styles.nonEditableInput,
                ]}
                value={historyData[item].dinner}
                onChangeText={(text) => handleDinnerChange(text, item)}
                editable={editable}
                multiline={true}
              />
            </View>
          ))}

          <TouchableOpacity
            style={[
              styles.editButton,
              { backgroundColor: editable ? COLORS.green : COLORS.brown },
            ]}
            onPress={toggleEditable}
          >
            <Text style={styles.editButtonText}>
              {editable ? "DONE" : "EDIT"}
            </Text>
          </TouchableOpacity>
        </View>
      </KeyboardAwareScrollView>
      <NetworkStatus />
    </View>
  );
};

export default History;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.cream,
  },
  screen: {
    justifyContent: "center",
    alignItems: "center",
  },
  header: {
    flexDirection: "row",
    marginBottom: verticalScale(10),
    justifyContent: "space-evenly",
    alignItems: "center",
    width: "72%",
    marginVertical: verticalScale(10),
    marginLeft: "18%",
  },
  row: {
    flexDirection: "row",
    marginBottom: verticalScale(10),
    width: "90%",
    justifyContent: "space-evenly",
  },
  cell: {
    fontSize: moderateScale(12),
    alignItems: "center",
    justifyContent: "center",
    borderWidth: moderateScale(2),
    borderColor: COLORS.lightOrange,
    padding: moderateScale(10),
    width: "36%",
    borderRadius: moderateScale(10),
    backgroundColor: "#FFFAEF",
    shadowColor: "#000",
    shadowOffset: {
      width: horizontalScale(0),
      height: verticalScale(3),
    },
    shadowOpacity: 0.25,
    shadowRadius: moderateScale(4),
    elevation: 5,
  },
  headerCell: {
    alignItems: "center",
    justifyContent: "center",
    borderWidth: moderateScale(1),
    borderColor: COLORS.brown,
    padding: moderateScale(10),
    width: "45%",
    borderRadius: moderateScale(10),
    backgroundColor: "#A0551D",
    shadowColor: "#000",
    shadowOffset: {
      width: horizontalScale(0),
      height: verticalScale(3),
    },
    shadowOpacity: 0.25,
    shadowRadius: moderateScale(4),
    elevation: 5,
  },
  headerText: {
    alignSelf: "center",
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(13),
    color: COLORS.cream,
  },
  dayCell: {
    alignItems: "center",
    justifyContent: "center",
    borderWidth: moderateScale(1),
    borderColor: COLORS.lightOrange,
    width: "18%",
    borderRadius: moderateScale(10),
    backgroundColor: COLORS.lightOrange,
    shadowColor: "#000",
    shadowOffset: {
      width: horizontalScale(0),
      height: verticalScale(3),
    },
    shadowOpacity: 0.25,
    shadowRadius: moderateScale(4),
    elevation: 5,
  },
  dayText: {
    alignSelf: "center",
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(12),
    color: COLORS.cream,
  },
  editButton: {
    backgroundColor: COLORS.brown,
    paddingHorizontal: moderateScale(6),
    padding: moderateScale(8),
    borderRadius: moderateScale(5),
    width: moderateScale(80), // Adjusted width for equal spacing
    alignSelf: "flex-end",
    marginRight: "8%",
    marginTop: "10%",
  },
  editButtonActive: {
    backgroundColor: COLORS.green, // Change color when in "EDIT" state
  },
  editButtonText: {
    fontSize: moderateScale(12),
    color: COLORS.cream,
    textAlign: "center", // Center text
    fontFamily: "LexendDeca-Bold",
  },
  editableInput: {
    color: "#ABAAAA",
    fontFamily: "LexendDeca-Regular",
  },
  nonEditableInput: {
    color: COLORS.lightOrange,
    fontFamily: "LexendDeca-Medium",
  },
});
