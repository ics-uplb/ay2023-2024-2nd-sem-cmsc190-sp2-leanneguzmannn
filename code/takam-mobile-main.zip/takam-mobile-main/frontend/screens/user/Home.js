import React, { useEffect, useState } from "react";
import {
  BackHandler,
  Image,
  ImageBackground,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { ScrollView } from "react-native-gesture-handler";
import { auth } from "../../../backend/firebase";
import firebaseAPI from "../../../backend/firebase-api";
import { COLORS, IMGS } from "../../assets";
import Loading from "../../navigation/Loading";
import CustomAlert from "../../utilities/CustomAlert";
import NetworkStatus from "../../utilities/NetworkStatus";
import { horizontalScale, moderateScale, verticalScale } from "../Scaling";

const Home = (props) => {
  const { navigation } = props;

  const imageSources = [
    IMGS.SLIDE1,
    IMGS.SLIDE2,
    IMGS.SLIDE3,
    IMGS.SLIDE4,
    IMGS.SLIDE5,
    IMGS.SLIDE6,
    IMGS.SLIDE7,
    IMGS.SLIDE8,
    IMGS.SLIDE9,
  ];

  const currentDate = new Date();
  const currHour24 = currentDate.getHours();
  const currHour12 =
    currHour24 > 12 ? currHour24 - 12 : currHour24 === 0 ? 12 : currHour24;
  const amPm = currHour24 < 12 ? "AM" : "PM";
  const currTime = `${currHour12}:${currentDate
    .getMinutes()
    .toString()
    .padStart(2, "0")} ${amPm}`;

  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const [timeOfDay, setTimeOfDay] = useState("");
  const [foodOfDay, setFoodOfDay] = useState("");

  const [showAlert, setShowAlert] = useState(false);
  const [showAlert2, setShowAlert2] = useState(false);
  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");

  const [userData, setUserData] = useState({});

  const [isLoading, setIsLoading] = useState(true);

  const fetchUserData = async () => {
    try {
      setUserData(await firebaseAPI.fetchUserData(auth.currentUser?.uid));
    } catch (error) {
      console.log("Fetch User Data Error: ", error.message);
      setTitle("Fetch User Data Error");
      setSubtitle(error.message);
      setShowAlert(true);
    }
  };

  useEffect(() => {
    setIsLoading(true);

    const interval = setInterval(() => {
      setCurrentImageIndex(
        (prevIndex) => (prevIndex + 1) % imageSources.length
      );
    }, 700);

    const getCurrentTime = () => {
      if (currHour24 >= 5 && currHour24 < 12) {
        setTimeOfDay("Umaga");
        setFoodOfDay("almusal");
      } else if (currHour24 >= 12 && currHour24 < 18) {
        setTimeOfDay("Hapon");
        setFoodOfDay("tanghalian");
      } else {
        setTimeOfDay("Gabi");
        setFoodOfDay("hapunan");
      }
    };

    const initializeLogin = async () => {
      await firebaseAPI.initUponLogin();
    };

    getCurrentTime();

    fetchUserData();

    initializeLogin().then(() => setIsLoading(false));

    const handleBackPress = () => {
      // Exit the app if user tries to go back to auth screen while logged in
      setTitle("Exit App");
      setSubtitle("Exiting the application?");
      setShowAlert2(true);

      return true;
    };

    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () => {
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
    };
  }, [navigation]);

  const renderTimeImage = () => {
    switch (timeOfDay) {
      case "Umaga":
        return IMGS.DAY;
      case "Hapon":
        return IMGS.NOON;
      case "Gabi":
        return IMGS.NIGHT;
    }
  };

  const renderMainContent = () => (
    <View style={styles.container}>
      <ScrollView
        decelerationRate="fast"
        style={{ width: "100%" }}
        contentContainerStyle={{
          flex: 1,
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <View>
          <ImageBackground source={renderTimeImage()} style={styles.display}>
            <Text
              style={
                timeOfDay !== "Umaga"
                  ? styles.time
                  : [{ ...styles.time, color: COLORS.lightBlue }]
              }
            >
              {currTime}
            </Text>
            <Text
              style={
                timeOfDay !== "Umaga"
                  ? styles.greeting
                  : [{ ...styles.greeting, color: COLORS.lightBlue }]
              }
            >
              Magandang {timeOfDay}, {userData.fName}
            </Text>
          </ImageBackground>
        </View>
        <View style={styles.bottomtxt}>
          <Text style={styles.textStyle}> Ano ang </Text>
          <Text style={styles.textStyle}> gusto mong </Text>
          <Text style={styles.textStyleBold}> {foodOfDay}? </Text>
        </View>
        <View>
          <Image
            source={imageSources[currentImageIndex]}
            style={styles.image}
          />
        </View>
      </ScrollView>
      {showAlert ? (
        <CustomAlert
          title={title}
          subtitle={subtitle}
          animationType="fade"
          transparent={true}
          visible={showAlert}
          cancelEnabled={false}
          onRequestClose={() => {
            setShowAlert(false);
          }}
          onConfirm={() => setShowAlert(false)}
        />
      ) : (
        <></>
      )}
      {showAlert2 ? (
        <CustomAlert
          title={title}
          subtitle={subtitle}
          animationType="fade"
          transparent={true}
          visible={showAlert2}
          cancelEnabled={true}
          onRequestClose={() => {
            setShowAlert2(false);
          }}
          onConfirm={() => BackHandler.exitApp()}
        />
      ) : (
        <></>
      )}
      <NetworkStatus />
    </View>
  );

  return isLoading ? <Loading /> : renderMainContent();
};

export default Home;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.cream,
  },
  display: {
    width: horizontalScale(330),
    height: verticalScale(175),
    bottom: verticalScale(40),
  },
  time: {
    fontFamily: "LexendDeca-SemiBold",
    fontSize: moderateScale(42),
    color: COLORS.white,
    paddingTop: verticalScale(40),
    left: horizontalScale(20),
  },
  greeting: {
    fontFamily: "LexendDeca-SemiBold",
    fontSize: moderateScale(18),
    color: COLORS.white,
    paddingTop: verticalScale(40),
    left: horizontalScale(20),
  },
  bottomtxt: {
    justifyContent: "right",
    alignItems: "right",
    right: horizontalScale(60),
    bottom: verticalScale(20),
  },
  textStyle: {
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(30),
    color: COLORS.orange,
  },
  textStyleBold: {
    fontFamily: "LexendDeca-Bold",
    fontSize: moderateScale(30),
    color: COLORS.orange,
  },
  image: {
    top: verticalScale(25),
    width: horizontalScale(290),
    height: verticalScale(210),
  },
});
