import { AntDesign, MaterialIcons } from "@expo/vector-icons";
import moment from "moment";
import React, { memo, useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  BackHandler,
  FlatList,
  Image,
  Modal,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { auth } from "../../../backend/firebase";
import firebaseAPI from "../../../backend/firebase-api";
import {
  formatFirebaseTimestamp,
  stringToFirebaseTimestamp,
} from "../../../utilities/formatDate";
import { COLORS } from "../../assets";
import CustomAlert from "../../utilities/CustomAlert";
import NetworkStatus from "../../utilities/NetworkStatus";
import { horizontalScale, moderateScale, verticalScale } from "../Scaling";

const Inventory = (props) => {
  const { navigation } = props;

  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [clickedIngredient, setClickedIngredient] = useState({});
  const [editable, setEditable] = useState(false);

  const [showAlert, setShowAlert] = useState(false);
  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");

  const [currentPage, setCurrentPage] = useState(0);
  const ingredientsPerPage = 25;

  const [modalVisible, setModalVisible] = useState(false);

  const toggleEditable = () => {
    setEditable(!editable);
  };

  const handleOutsidePress = () => {
    setModalVisible(false);
  };

  const RenderIngredientItem = memo(({ item }) => {
    return (
      <View style={styles.ingredient}>
        <TouchableOpacity
          onPress={() => {
            if (!item.empty) {
              setClickedIngredient(item);
              setModalVisible(true);
            }
          }}
        >
          <Image
            source={{ uri: item.imageUrl }}
            style={{
              aspectRatio: 1,
              width: horizontalScale(55),
              resizeMode: "contain",
            }}
          />
        </TouchableOpacity>
      </View>
    );
  });

  const renderRowSeparator = () => <View style={styles.rowSeparator} />;

  const goToNextPage = () => {
    setCurrentPage(currentPage + 1);
  };

  const goToPreviousPage = () => {
    setCurrentPage(currentPage - 1);
  };

  const [allIngredients, setAllIngredients] = useState([]);
  const [availableIngredients, setAvailableIngredients] = useState([]);

  const handleIngredientsList = async () => {
    try {
      setAllIngredients(
        await firebaseAPI.fetchIngredientsList(auth.currentUser.uid)
      );
    } catch (error) {
      console.log("Error fetching ingredients: ", error.message);
      setTitle("Error fetching ingredients");
      setSubtitle(error.message);
      setShowAlert(true);
    }
  };

  useEffect(() => {
    // Function to fetch the ingredients
    const fetchIngredientsList = () => {
      setIsLoading(true);

      handleIngredientsList()
        .then(() => {
          setIsLoading(false);
        })
        .catch((error) => {
          console.log(error.message);
          setIsLoading(false);
        });
    };

    fetchIngredientsList();

    // Listen for changes to the navigation state
    const unsubscribe = navigation.addListener("focus", () => {
      // Call the fetchIngredientsList function again if the screen is in focus
      fetchIngredientsList();
    });

    const handleBackPress = () => {
      navigation.goBack();
      return true;
    };

    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () => {
      // Unsubscribe from the focus event when the component unmounts
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
      unsubscribe;
    };
  }, [navigation]);

  useEffect(() => {
    const ingredientsWithSupply = allIngredients.filter(
      (ingredient) => ingredient.supply !== null
    );
    setAvailableIngredients(ingredientsWithSupply);
  }, [allIngredients]);

  const padData = (data, fixedNumber) => {
    const paddingCount = Math.max(0, fixedNumber - data.length);
    const paddedData = [...data];

    for (let i = 0; i < paddingCount; i++) {
      paddedData.push({ empty: true });
    }

    return paddedData;
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);

    // Function to re-fetch the ingredients
    const fetchIngredientsList = () => {
      setRefreshing(true);

      handleIngredientsList()
        .then(() => {
          setRefreshing(false);
        })
        .catch((error) => {
          console.log(error.message);
          setRefreshing(false);
        });
    };

    fetchIngredientsList();
  }, [availableIngredients]);

  const startIndex = currentPage * ingredientsPerPage;
  const endIndex = Math.min(
    startIndex + ingredientsPerPage,
    availableIngredients.length
  );
  const data = availableIngredients.slice(startIndex, endIndex);
  const paddedData = padData(data, 25);

  const ModalComponent = ({ ingredient }) => {
    const [supplyData, setSupplyData] = useState(
      ingredient.supply.map((supply) => ({
        ...supply,
        expirationDate: formatFirebaseTimestamp(supply.expirationDate),
        quantity: supply.quantity.toString(),
      }))
    );

    const handleInputChange = (index, field, value) => {
      const updatedSupply = [...supplyData];
      updatedSupply[index][field] = value;
      setSupplyData(updatedSupply);
    };

    const isValidDate = (date) => {
      return moment(date, "MM/DD/YYYY", true).isValid();
    };

    const isConfirmDisabled = () => {
      return supplyData.some(
        (supply) =>
          !isValidDate(supply.expirationDate) ||
          isNaN(supply.quantity) ||
          supply.expirationDate.trim() === "" ||
          supply.quantity.trim() === ""
      );
    };

    const handleConfirm = async (ingredientId, supplyData) => {
      // Save the updated supply data to the database
      await firebaseAPI.updateIngredientSupply(
        auth.currentUser.uid,
        ingredientId,
        supplyData
      );

      // Update the supply property of the corresponding ingredient
      const ingredientIndex = availableIngredients.findIndex(
        (ingredient) => ingredient.id === ingredientId
      );

      if (ingredientIndex === -1) {
        // If ingredient not found, exit early
        setModalVisible(false);
        return;
      }

      const updatedIngredients = [...availableIngredients];

      // Remove supplies with quantity zero
      const filteredSupplyData = supplyData.filter(
        (supply) => supply.quantity > 0
      );

      // If filteredSupplyData is empty, remove the current item from availableIngredients
      if (filteredSupplyData.length === 0) {
        updatedIngredients.splice(ingredientIndex, 1);
        setAvailableIngredients(updatedIngredients);
        setModalVisible(false);
        return;
      }

      const updatedSupplyData = filteredSupplyData.map((supply) => ({
        ...supply,
        expirationDate: stringToFirebaseTimestamp(supply.expirationDate),
      }));

      // Calculate total quantity
      let totalQuantity = 0;
      updatedSupplyData.forEach((supply) => {
        totalQuantity += parseInt(supply.quantity);
      });

      updatedIngredients[ingredientIndex].supply = updatedSupplyData;
      updatedIngredients[ingredientIndex].totalQuantity = totalQuantity;

      setAvailableIngredients(updatedIngredients);
      setModalVisible(false);
    };

    return (
      <Modal
        animationType="none"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(!modalVisible);
        }}
      >
        <View style={styles.overlay}>
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <TouchableOpacity onPress={handleOutsidePress}>
                <View
                  style={{
                    alignSelf: "flex-end",
                  }}
                >
                  <AntDesign
                    name="close"
                    size={moderateScale(20)}
                    color={COLORS.black}
                  />
                </View>
              </TouchableOpacity>
              <View style={styles.rowContainer}>
                <Image
                  source={{ uri: ingredient.imageUrl }}
                  style={styles.image}
                />
                <View style={styles.columnContainer}>
                  <Text style={styles.modalTextName}>{ingredient.name}</Text>
                  <Text style={styles.modalTextStock}>
                    Stock: {ingredient.totalQuantity} {ingredient.measuredBy}
                  </Text>
                </View>
              </View>
              <View style={{ maxHeight: "36%" }}>
                <ScrollView decelerationRate="fast" style={{ width: "100%" }}>
                  <KeyboardAwareScrollView
                    enableOnAndroid={true}
                    showsVerticalScrollIndicator={false}
                  >
                    {supplyData.map((supply, index) => (
                      <View style={styles.indvStock} key={index}>
                        <Text style={styles.modalText}>
                          Date Bought:{" "}
                          {formatFirebaseTimestamp(supply.dateAdded)}
                        </Text>
                        <View style={styles.actionContainer}>
                          <Text style={styles.modalText}>
                            Expiration Date:{" "}
                          </Text>
                          <TextInput
                            style={[
                              styles.modalTextInput,
                              {
                                color: editable
                                  ? COLORS.green
                                  : COLORS.darkBrown,
                              },
                            ]}
                            editable={editable}
                            value={supply.expirationDate}
                            onChangeText={(value) =>
                              handleInputChange(index, "expirationDate", value)
                            }
                          />
                          <View style={styles.iconContainer}>
                            <TouchableOpacity onPress={toggleEditable}>
                              <MaterialIcons
                                name="mode-edit"
                                size={15}
                                color={COLORS.darkBrown}
                              />
                            </TouchableOpacity>
                          </View>
                        </View>
                        <View style={styles.actionContainer}>
                          <Text style={styles.modalText}>Stock: </Text>
                          <TextInput
                            style={[
                              styles.modalTextInput,
                              {
                                color: editable
                                  ? COLORS.green
                                  : COLORS.darkBrown,
                              },
                            ]}
                            editable={editable}
                            value={supply.quantity}
                            onChangeText={(value) =>
                              handleInputChange(index, "quantity", value)
                            }
                            keyboardType="numeric"
                          ></TextInput>
                          <View style={styles.iconContainer}>
                            <TouchableOpacity onPress={toggleEditable}>
                              <MaterialIcons
                                name="mode-edit"
                                size={15}
                                color={COLORS.darkBrown}
                              />
                            </TouchableOpacity>
                          </View>
                        </View>
                      </View>
                    ))}
                  </KeyboardAwareScrollView>
                </ScrollView>
              </View>
              <TouchableOpacity
                style={[
                  styles.button,
                  {
                    backgroundColor: isConfirmDisabled()
                      ? COLORS.disabledGray
                      : COLORS.green,
                    borderColor: isConfirmDisabled()
                      ? COLORS.disabledGray
                      : COLORS.green,
                  },
                ]}
                disabled={isConfirmDisabled()}
                onPress={() => handleConfirm(ingredient.id, supplyData)}
              >
                <Text style={styles.button1Text}>CONFIRM</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  };

  return (
    <View style={styles.container}>
      {isLoading ? (
        <View style={styles.loadingIndicator}>
          <ActivityIndicator size="large" color={COLORS.lightOrange} />
        </View>
      ) : (
        <>
          {modalVisible && <ModalComponent ingredient={clickedIngredient} />}
          <View style={styles.cabinet}>
            <View style={styles.shelf}>
              <FlatList
                data={paddedData}
                renderItem={({ item }) => <RenderIngredientItem item={item} />}
                keyExtractor={(item, index) => index.toString()}
                numColumns={5}
                ItemSeparatorComponent={renderRowSeparator}
                ListFooterComponent={renderRowSeparator}
                style={{ width: "100%" }}
                refreshControl={
                  <RefreshControl
                    refreshing={refreshing}
                    onRefresh={onRefresh}
                  />
                }
              />
            </View>
          </View>

          <View
            style={{
              flexDirection: "row",
              width: "90%",
              justifyContent: "space-evenly",
            }}
          >
            <TouchableOpacity
              onPress={goToPreviousPage}
              disabled={currentPage <= 0}
            >
              <Text
                style={[
                  styles.pageNavigationText,
                  {
                    color:
                      currentPage <= 0 ? COLORS.disabledGray : COLORS.brown,
                  },
                ]}
              >
                Previous
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={goToNextPage}
              disabled={
                currentPage >=
                Math.ceil(availableIngredients.length / ingredientsPerPage) - 1
              }
            >
              <Text
                style={[
                  styles.pageNavigationText,
                  {
                    color:
                      currentPage >=
                      Math.ceil(
                        availableIngredients.length / ingredientsPerPage
                      ) -
                        1
                        ? COLORS.disabledGray
                        : COLORS.brown,
                  },
                ]}
              >
                Next
              </Text>
            </TouchableOpacity>
          </View>
        </>
      )}
      {showAlert ? (
        <CustomAlert
          title={title}
          subtitle={subtitle}
          animationType="fade"
          transparent={true}
          visible={showAlert}
          cancelEnabled={false}
          onRequestClose={() => {
            setShowAlert(false);
          }}
          onConfirm={() => setShowAlert(false)}
        />
      ) : (
        <></>
      )}
      <NetworkStatus />
    </View>
  );
};

export default Inventory;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.cream,
  },
  cabinet: {
    backgroundColor: "#A3482A",
    width: "90%",
    alignItems: "center",
    marginVertical: verticalScale(10),
  },
  shelf: {
    backgroundColor: "#3E180C",
    marginVertical: verticalScale(20),
    width: "90%",
  },
  ingredient: {
    width: "20%",
    alignItems: "center",
    justifyContent: "flex-end",
    minHeight: verticalScale(50),
    marginTop: verticalScale(20),
  },
  rowSeparator: {
    height: verticalScale(20),
    backgroundColor: "#642A18",
  },

  centeredView: {
    justifyContent: "center",
    alignItems: "center",
    width: "80%",
  },
  rowContainer: {
    flexDirection: "row",
    width: "100%",
    paddingBottom: verticalScale(7),
    paddingHorizontal: horizontalScale(8),
  },
  columnContainer: {
    color: COLORS.green,
    flexDirection: "column",
    width: "60%",
    marginVertical: moderateScale(10),
    marginLeft: horizontalScale(20),
  },
  indvStock: {
    alignItems: "flex-start",
    paddingBottom: moderateScale(10),
    paddingHorizontal: horizontalScale(10),
  },
  actionContainer: {
    flexDirection: "row",
    marginRight: horizontalScale(2),
    alignContent: "center",
    alignItems: "center",
    justifyContent: "center",
  },
  iconContainer: {
    flexDirection: "row",
    marginTop: verticalScale(1),
    marginLeft: horizontalScale(4),
  },
  modalView: {
    width: "90%",
    backgroundColor: COLORS.cream,
    borderRadius: moderateScale(20),
    padding: moderateScale(10),
    shadowColor: "#000",
    shadowOffset: {
      width: horizontalScale(0),
      height: verticalScale(2),
    },
    shadowOpacity: 0.25,
    shadowRadius: moderateScale(4),
    elevation: 5,
  },
  pageNavigationText: {
    fontFamily: "LexendDeca-Bold",
    fontSize: moderateScale(14),
    color: COLORS.brown,
  },
  modalTextName: {
    textAlign: "left",
    fontFamily: "LexendDeca-Bold",
    fontSize: moderateScale(20),
    color: COLORS.darkBrown,
    flexWrap: "wrap",
  },
  modalTextStock: {
    textAlign: "left",
    fontFamily: "LexendDeca-Bold",
    fontSize: moderateScale(14),
    color: COLORS.darkBrown,
  },
  modalText: {
    textAlign: "left",
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(13),
    color: COLORS.darkBrown,
    flexWrap: "wrap",
  },
  modalTextInput: {
    textAlign: "left",
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(13),
    color: COLORS.darkBrown,
    flexWrap: "wrap",
  },
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)", // semi-transparent black
    justifyContent: "center",
    alignItems: "center",
  },
  image: {
    height: verticalScale(70),
    width: horizontalScale(70),
  },
  button1Text: {
    fontSize: moderateScale(12),
    color: COLORS.cream,
    textAlign: "center", // Center text
    fontFamily: "LexendDeca-Medium",
  },
  button: {
    backgroundColor: COLORS.green,
    paddingHorizontal: moderateScale(6),
    alignSelf: "center",
    padding: moderateScale(3),
    borderRadius: moderateScale(5),
    borderWidth: moderateScale(2), // Add border width
    borderColor: COLORS.green, // Add border color
    width: moderateScale(80), // Adjusted width for equal spacing
  },
});
