import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  BackHandler,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { auth } from "../../../backend/firebase";
import firebaseAPI from "../../../backend/firebase-api";
import ROUTES from "../../../utilities/Routes";
import { COLORS } from "../../assets";
import { horizontalScale, moderateScale, verticalScale } from "../Scaling";
import NetworkStatus from "../../utilities/NetworkStatus";

const MealPlan = (props) => {
  const { navigation } = props;

  const [isLoading, setIsLoading] = useState(true);
  const [mealPlans, setMealPlans] = useState({
    MON: { lunch: {}, dinner: {} },
    TUE: { lunch: {}, dinner: {} },
    WED: { lunch: {}, dinner: {} },
    THU: { lunch: {}, dinner: {} },
    FRI: { lunch: {}, dinner: {} },
    SAT: { lunch: {}, dinner: {} },
    SUN: { lunch: {}, dinner: {} },
  });

  useEffect(() => {
    const fetchMealPlans = async () => {
      setIsLoading(true);

      try {
        const mealPlanData = await firebaseAPI.fetchMealPlanData(
          auth.currentUser.uid
        );
        setMealPlans(mealPlanData);
      } catch (error) {
        console.error("Error fetching meal plans:", error);
      }

      setIsLoading(false);
    };

    fetchMealPlans();

    const handleBackPress = () => {
      navigation.goBack();
      return true;
    };

    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () => {
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
    };
  }, []);

  const columnButtons = ["lunch", "dinner"];
  const rowButtons = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];

  const handleRecipePress = (recipe) => {
    navigation.navigate(ROUTES.USER_RECIPEPAGE, { recipe });
  };

  return (
    <View style={styles.container}>
      {isLoading ? (
        <View style={styles.loadingIndicator}>
          <ActivityIndicator size="large" color={COLORS.lightOrange} />
        </View>
      ) : (
        <ScrollView decelerationRate="fast">
          <View style={styles.columnHeaderContainer}>
            {columnButtons.map((label, index) => (
              <View key={index} style={styles.columnHeader}>
                <View style={styles.outlineButton}>
                  <Text style={styles.buttonText}>{label}</Text>
                </View>
              </View>
            ))}
          </View>
          <View style={styles.rowContainer}>
            {rowButtons.map((day, rowIndex) => (
              <View key={rowIndex} style={styles.row}>
                <View style={styles.dayContainer}>
                  <Text style={styles.dayText}>{day}</Text>
                </View>
                <TouchableOpacity
                  onPress={() => handleRecipePress(mealPlans[day].lunch)}
                  style={styles.recipeImageContainer}
                >
                  {mealPlans[day].lunch.mainImageUrl && (
                    <Image
                      source={{ uri: mealPlans[day].lunch.mainImageUrl }}
                      style={styles.recipeImage}
                    />
                  )}
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => handleRecipePress(mealPlans[day].dinner)}
                  style={styles.recipeImageContainer}
                >
                  {mealPlans[day].dinner.mainImageUrl && (
                    <Image
                      source={{ uri: mealPlans[day].dinner.mainImageUrl }}
                      style={styles.recipeImage}
                    />
                  )}
                </TouchableOpacity>
              </View>
            ))}
          </View>
        </ScrollView>
      )}
      <NetworkStatus />
    </View>
  );
};

export default MealPlan;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.cream,
    paddingHorizontal: horizontalScale(10),
    paddingTop: horizontalScale(10),
    justifyContent: "center",
    alignItems: "center",
  },
  columnHeaderContainer: {
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
    width: "90%",
    marginVertical: verticalScale(10),
    marginLeft: "10%",
  },
  columnHeader: {
    width: horizontalScale(120),
    alignItems: "center",
  },
  outlineButton: {
    backgroundColor: "transparent",
    padding: moderateScale(3),
    paddingHorizontal: horizontalScale(8),
    borderRadius: moderateScale(5),
    borderWidth: moderateScale(2),
    borderColor: COLORS.darkBrown,
    width: "100%",
  },
  buttonText: {
    fontSize: moderateScale(13),
    color: COLORS.darkBrown,
    textAlign: "center",
    fontFamily: "LexendDeca-Medium",
    alignSelf: "center",
  },
  rowContainer: {
    flexDirection: "column",
    marginTop: verticalScale(10),
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: verticalScale(10),
    justifyContent: "space-evenly",
  },
  dayContainer: {
    width: "8%",
    borderColor: COLORS.lightOrange,
    borderWidth: moderateScale(2),
    borderRadius: horizontalScale(6),
    paddingHorizontal: horizontalScale(5),
  },
  dayText: {
    textAlign: "center",
    flexWrap: "wrap",
    color: COLORS.lightOrange,
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(15),
  },
  recipeImageContainer: {
    width: "40%",
    alignItems: "center",
  },
  recipeImage: {
    width: horizontalScale(120),
    height: verticalScale(120),
    resizeMode: "cover",
  },
});
