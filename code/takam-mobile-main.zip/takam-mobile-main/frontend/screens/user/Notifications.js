import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  BackHandler,
  FlatList,
  StyleSheet,
  Text,
  View,
} from "react-native";
import firebaseAPI from "../../../backend/firebase-api";
import { COLORS } from "../../assets";
import NetworkStatus from "../../utilities/NetworkStatus";
import { horizontalScale, moderateScale, verticalScale } from "../Scaling";

const Notifications = (props) => {
  const { navigation } = props;

  const [notificationsList, setNotificationsList] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchNotifications = async () => {
      setIsLoading(true);

      try {
        const notificationsData = await firebaseAPI.fetchNotifications();

        setNotificationsList(notificationsData);
      } catch (error) {
        console.error("Error fetching notifications list:", error);
      }

      setIsLoading(false);
    };

    fetchNotifications();

    const handleBackPress = () => {
      navigation.goBack();
      return true;
    };

    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () => {
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
    };
  }, []);

  const formatTimeElapsed = (notificationTime) => {
    const formattedNotifTime = new Date(notificationTime)

    const currentTime = new Date();
    const timeDifference = currentTime.getTime() - formattedNotifTime.getTime();
    const seconds = Math.floor(timeDifference / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) {
      return `${days} day${days > 1 ? "s" : ""} ago`;
    } else if (hours > 0) {
      return `${hours} hour${hours > 1 ? "s" : ""} ago`;
    } else if (minutes > 0) {
      return `${minutes} minute${minutes > 1 ? "s" : ""} ago`;
    } else {
      return `${seconds} second${seconds !== 1 ? "s" : ""} ago`;
    }
  };

  const renderItem = ({ item }) => (
    <View style={styles.notificationItem}>
      <Text style={styles.message}>{item.message}</Text>
      <Text style={styles.time}>{formatTimeElapsed(item.time)}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      {isLoading ? (
        <View style={styles.loadingIndicator}>
          <ActivityIndicator size="large" color={COLORS.lightOrange} />
        </View>
      ) : (
        <FlatList
          data={notificationsList}
          ListEmptyComponent={
            <Text style={styles.title}>No New Notifications</Text>
          }
          renderItem={renderItem}
          keyExtractor={(item) => item.id.toString()}
          style={{ width: "100%" }}
        />
      )}
      <NetworkStatus />
    </View>
  );
};

export default Notifications;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: "100%",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.darkCream,
    padding: moderateScale(15),
  },
  title: {
    fontSize: moderateScale(20),
    flexWrap: "wrap",
    fontFamily: "LexendDeca-Medium",
    color: "#888",
    marginBottom: moderateScale(20),
    alignSelf: "center",
  },
  notificationItem: {
    padding: moderateScale(10),
    marginBottom: horizontalScale(10),
    borderRadius: moderateScale(10),
    backgroundColor: COLORS.cream,
    shadowColor: "#000",
    shadowOffset: {
      width: horizontalScale(0),
      height: verticalScale(3),
    },
    shadowOpacity: 0.25,
    shadowRadius: moderateScale(4),
    elevation: 5,
  },
  message: {
    fontSize: moderateScale(16),
    flexWrap: "wrap",
    fontFamily: "LexendDeca-Medium",
    color: COLORS.orange,
  },
  time: {
    fontSize: moderateScale(12),
    color: "#888",
    marginTop: horizontalScale(5),
    fontFamily: "LexendDeca-Light",
  },
});
