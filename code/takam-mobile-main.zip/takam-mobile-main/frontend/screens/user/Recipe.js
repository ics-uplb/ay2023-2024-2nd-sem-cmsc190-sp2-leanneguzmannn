import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  BackHandler,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { ScrollView } from "react-native-gesture-handler";
import firebaseAPI from "../../../backend/firebase-api";
import ROUTES from "../../../utilities/Routes";
import { COLORS } from "../../assets";
import NetworkStatus from "../../utilities/NetworkStatus";
import { horizontalScale, moderateScale, verticalScale } from "../Scaling";

const Recipe = (props) => {
  const { navigation } = props;

  const [isLoading, setIsLoading] = useState(true);
  const [recipes, setRecipes] = useState([]);
  const [selectedButton, setSelectedButton] = useState("All");
  const [filterButton, setFilterButton] = useState("");

  const [showDifficulty, setShowDifficulty] = useState(false);
  const [filterInventory, setFilterInventory] = useState(false);

  const [filteredRecipes, setFilteredRecipes] = useState([]);

  useEffect(() => {
    const fetchRecipes = async () => {
      setIsLoading(true);

      try {
        const recipesData = await firebaseAPI.fetchRecipesList();

        setRecipes(recipesData);
        setFilteredRecipes(recipesData);
      } catch (error) {
        console.error("Error fetching recipes:", error);
      }

      setIsLoading(false);
    };

    fetchRecipes();

    const handleBackPress = () => {
      navigation.goBack();
      return true;
    };

    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () => {
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
    };
  }, []);

  useEffect(() => {
    const filterCookableRecipes = async (recipes) => {
      try {
        // Create an array of promises that resolve to true or false for each recipe
        const cookableChecks = recipes.map(async (recipe) => {
          const canCook = await firebaseAPI.isCookableMissing(
            recipes,
            recipe.id
          );
          return { recipe, canCook };
        });

        // Wait for all the promises to resolve
        const results = await Promise.all(cookableChecks);

        // Filter the recipes based on the results
        const cookableRecipes = results
          .filter((result) => result.canCook)
          .map((result) => result.recipe);

        return cookableRecipes;
      } catch (error) {
        console.error("Error filtering cookable recipes:", error);
        throw new Error("Error filtering cookable recipes:", error);
      }
    };

    const filterRecipes = async () => {
      if (filterInventory) {
        setFilteredRecipes(await filterCookableRecipes(recipes));
      } else {
        setFilteredRecipes(recipes);
      }
    };

    filterRecipes();
  }, [filterInventory]);

  useEffect(() => {
    if (filterButton === "Difficulty") {
      let filteredRecipesData = recipes;

      if (selectedButton !== "All") {
        filteredRecipesData = recipes.filter(
          (recipe) => recipe.difficulty === selectedButton
        );

        setFilteredRecipes(filteredRecipesData);
      } else {
        setFilteredRecipes(filteredRecipesData);
      }
    }
  }, [filterButton, selectedButton]);

  const handleDifficulty = () => {
    setFilterButton("Difficulty");
    setShowDifficulty(!showDifficulty);
    setFilterInventory(false);
    setSelectedButton("All");
  };

  const handleInventoryBtn = () => {
    setFilterButton("Inventory");
    setShowDifficulty(false);
    setFilterInventory(!filterInventory);
  };

  return (
    <View style={styles.container}>
      {isLoading ? (
        <View style={styles.loadingIndicator}>
          <ActivityIndicator size="large" color={COLORS.lightOrange} />
        </View>
      ) : (
        <ScrollView
          decelerationRate="fast"
          style={{ width: "100%" }}
          contentContainerStyle={{
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <View style={styles.filter}>
            <View style={styles.rowContainer1}>
              <Text style={styles.modalText}>Filter by: </Text>
              <TouchableOpacity
                style={[
                  styles.outlineButton,
                  filterButton === "Inventory" &&
                    filterInventory &&
                    styles.selectedButton,
                ]}
                onPress={() => handleInventoryBtn()}
              >
                <Text style={styles.buttonText}>INVENTORY</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.outlineButton,
                  filterButton === "Difficulty" &&
                    showDifficulty &&
                    styles.selectedButton,
                ]}
                onPress={() => handleDifficulty()}
              >
                <Text style={styles.buttonText}>DIFFICULTY</Text>
              </TouchableOpacity>
            </View>
            {showDifficulty ? (
              <View style={styles.rowContainer2}>
                <TouchableOpacity
                  style={[
                    styles.outlineButton,
                    selectedButton === "Easy" && styles.selectedButton,
                  ]}
                  onPress={() => setSelectedButton("Easy")}
                >
                  <Text style={styles.buttonText}>EASY</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[
                    styles.outlineButton,
                    selectedButton === "Medium" && styles.selectedButton,
                  ]}
                  onPress={() => setSelectedButton("Medium")}
                >
                  <Text style={styles.buttonText}>MEDIUM</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[
                    styles.outlineButton,
                    selectedButton === "Hard" && styles.selectedButton,
                  ]}
                  onPress={() => setSelectedButton("Hard")}
                >
                  <Text style={styles.buttonText}>HARD</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <></>
            )}
          </View>
          <View style={styles.container1}>
            {filteredRecipes.map((recipe, index) => (
              <View key={index} style={styles.imageContainer}>
                <TouchableOpacity
                  key={index}
                  style={styles.button}
                  onPress={() =>
                    navigation.navigate(ROUTES.USER_RECIPEPAGE, { recipe })
                  }
                >
                  <Image
                    source={{ uri: recipe.mainImageUrl }}
                    style={styles.image}
                  />
                </TouchableOpacity>
              </View>
            ))}
          </View>
        </ScrollView>
      )}
      <NetworkStatus />
    </View>
  );
};

export default Recipe;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.cream,
  },
  container1: {
    flex: 1,
    flexDirection: "row",
    flexWrap: "wrap",
    alignItems: "flex-start",
    justifyContent: "space-around",
  },
  button: {
    flex: 1,
    width: undefined,
    height: undefined,
    resizeMode: "cover",
  },
  imageContainer: {
    width: "45%",
    aspectRatio: 1,
    marginVertical: verticalScale(10),
  },
  image: {
    flex: 1,
    width: undefined,
    height: undefined,
    resizeMode: "cover",
  },
  rowContainer1: {
    flexDirection: "row",
    width: "100%",
    marginHorizontal: moderateScale(15),
    marginVertical: moderateScale(5),
  },
  rowContainer2: {
    flexDirection: "row",
    width: "100%",
    marginHorizontal: moderateScale(15),
    marginVertical: moderateScale(5),
    alignItems: "center",
    alignContent: "center",
    justifyContent: "center",
  },
  filter: {
    width: "100%",
  },
  modalText: {
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(18),
    color: COLORS.darkBrown,
  },
  outlineButton: {
    marginHorizontal: horizontalScale(5),
    backgroundColor: "transparent",
    paddingHorizontal: moderateScale(6),
    padding: moderateScale(3),
    borderRadius: moderateScale(5),
    borderWidth: moderateScale(2),
    borderColor: COLORS.darkBrown,
  },
  selectedButton: {
    backgroundColor: COLORS.lightOrange,
  },
  buttonText: {
    fontSize: moderateScale(12),
    color: COLORS.darkBrown,
    textAlign: "center",
    fontFamily: "LexendDeca-Medium",
  },
});
