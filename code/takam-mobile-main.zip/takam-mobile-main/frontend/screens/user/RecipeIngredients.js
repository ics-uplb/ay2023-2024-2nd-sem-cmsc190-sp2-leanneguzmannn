import React, { useEffect, useState } from "react";
import {
  BackHandler,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { ScrollView } from "react-native-gesture-handler";
import firebaseAPI from "../../../backend/firebase-api";
import ROUTES from "../../../utilities/Routes";
import { COLORS } from "../../assets";
import CustomAlert from "../../utilities/CustomAlert";
import NetworkStatus from "../../utilities/NetworkStatus";
import { horizontalScale, moderateScale, verticalScale } from "../Scaling";

const RecipeIngredients = ({ navigation, route }) => {
  const { recipe } = route.params;
  const [showAlert, setShowAlert] = useState(false);
  const [showAlert1, setShowAlert1] = useState(false);
  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");
  const [canCook, setCanCook] = useState(false);

  const [missingIngredientIdAlert, setMissingIngredientIdAlert] = useState("");

  const handlePressCook = async () => {
    try {
      await firebaseAPI.cookRecipe(recipe.id);

      navigation.navigate(ROUTES.USER_INSTRUCTIONS, {
        instructions: recipe.instructions,
        bannerImageUrl: recipe.bannerImageUrl,
      });
    } catch (error) {
      console.log("Error cooking recipe:", error.message);

      if (error.message === "Insufficient ingredients to cook the recipe") {
        setTitle("Insufficient Ingredients");
        setSubtitle("You don't have enough ingredients to cook the recipe.");
        setShowAlert(true);
      } else if (
        error.message.startsWith("Missing ingredient to cook the recipe:")
      ) {
        const match = error.message.match(/([a-zA-Z0-9]+) (\d+) (\w+) (.*)/);

        if (match && match.length === 5) {
          const missingIngredientId = match[1];
          const missingIngredientQuantity = match[2];
          const missingIngredientMeasuredBy = match[3];
          const missingIngredientName = match[4];

          setTitle("Insufficient Ingredients");
          setSubtitle(
            `You don't have enough ${missingIngredientName} (${missingIngredientQuantity} ${missingIngredientMeasuredBy}) to cook the recipe. Continue cooking?`
          );
          setMissingIngredientIdAlert(missingIngredientId);
          setCanCook(true);
          setShowAlert(true);
        }
      }
    }
  };

  const handlePressGrocery = async () => {
    try {
      await firebaseAPI.addRecipeIngredientGrocery(recipe.id);
      setTitle("Ingredients Added Successfully");
      setSubtitle(
        "You have successfully added the ingredients to the grocery list."
      );
      setShowAlert1(true);
    } catch (error) {
      setTitle("Error adding recipe ingredients to grocery list.");
      setSubtitle(error.message);
      setShowAlert1(true);
      console.log(
        "Error adding recipe ingredients to grocery list:",
        error.message
      );
    }
  };

  useEffect(() => {
    const handleBackPress = () => {
      navigation.goBack();
      return true;
    };

    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () => {
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
    };
  }, []);

  return (
    <View style={styles.container}>
      <ScrollView
        decelerationRate="fast"
        style={{ width: "100%" }}
        contentContainerStyle={{
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Image source={{ uri: recipe.bannerImageUrl }} style={styles.image} />
        <Text style={styles.textStyle}>Ingredients: </Text>
        {recipe.ingredientsDisplay.map((ingredient, index) => (
          <View key={index} style={styles.itemContainer}>
            <Text style={styles.bullet}>•</Text>
            <Text style={styles.ingredient}>{ingredient}</Text>
          </View>
        ))}
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.button} onPress={handlePressCook}>
            <Text style={styles.button1Text}>Cook Recipe</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.button, { backgroundColor: COLORS.brown }]}
            onPress={handlePressGrocery}
          >
            <Text style={styles.button1Text}>Add to Grocery</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
      {showAlert &&
        (canCook ? (
          <CustomAlert
            title={title}
            subtitle={subtitle}
            animationType="fade"
            transparent={true}
            visible={showAlert}
            cancelBtnName={"No"}
            confirmBtnName={"Yes"}
            cancelEnabled={true}
            onRequestClose={() => {
              setShowAlert(false);
            }}
            onConfirm={async () => {
              await firebaseAPI.cookRecipeWithMissingIngredient(
                recipe.id,
                missingIngredientIdAlert
              );

              navigation.navigate(ROUTES.USER_INSTRUCTIONS, {
                instructions: recipe.instructions,
                bannerImageUrl: recipe.bannerImageUrl,
              });
            }}
          />
        ) : (
          <CustomAlert
            title={title}
            subtitle={subtitle}
            animationType="fade"
            transparent={true}
            visible={showAlert}
            onRequestClose={() => {
              setShowAlert(false);
            }}
            onConfirm={() => setShowAlert(false)}
            cancelEnabled={false}
          />
        ))}
      {showAlert1 ? (
        <CustomAlert
          title={title}
          subtitle={subtitle}
          animationType="fade"
          transparent={true}
          visible={showAlert1}
          onRequestClose={() => {
            setShowAlert1(false);
          }}
          onConfirm={() => setShowAlert1(false)}
          cancelEnabled={false}
        />
      ) : (
        <></>
      )}
      <NetworkStatus />
    </View>
  );
};

export default RecipeIngredients;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.cream,
  },
  textStyle: {
    fontFamily: "LexendDeca-Bold",
    fontSize: moderateScale(22),
    color: COLORS.lightOrange,
    alignSelf: "flex-start",
    textAlign: "left",
    marginLeft: horizontalScale(30),
    paddingBottom: verticalScale(5),
  },
  image: {
    width: horizontalScale(340),
    height: verticalScale(190),
    marginVertical: verticalScale(20),
  },
  itemContainer: {
    width: "80%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginVertical: verticalScale(5),
    textAlign: "justify",
  },
  bullet: {
    fontSize: moderateScale(20),
    marginRight: moderateScale(5),
    color: COLORS.lightOrange,
  },
  ingredient: {
    fontSize: moderateScale(14),
    fontFamily: "LexendDeca-Medium",
    color: COLORS.lightOrange,
    textAlign: "justify",
    width: "100%",
  },
  button1Text: {
    fontSize: moderateScale(15),
    color: COLORS.cream,
    textAlign: "center",
    fontFamily: "LexendDeca-SemiBold",
    alignSelf: "center",
    justifyContent: "center",
    flexWrap: "wrap",
  },
  button: {
    alignItems: "center",
    justifyContent: "center",
    alignContent: "center",
    alignSelf: "flex-start",
    backgroundColor: COLORS.green,
    paddingHorizontal: moderateScale(6),
    paddingVertical: moderateScale(5),
    marginVertical: verticalScale(30),
    marginHorizontal: horizontalScale(20),
    //marginLeft: horizontalScale(30),
    padding: moderateScale(3),
    borderRadius: moderateScale(5),

    width: moderateScale(100), // Adjusted width for equal spacing
  },
  buttonContainer: {
    flexDirection: "row",
    marginTop: verticalScale(20),
    //alignItems: "right",
  },
});
