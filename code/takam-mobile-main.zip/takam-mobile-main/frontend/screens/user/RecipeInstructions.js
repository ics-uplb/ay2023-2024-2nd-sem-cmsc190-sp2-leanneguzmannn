import React, { useEffect } from "react";
import { BackHandler, Image, StyleSheet, Text, View } from "react-native";
import { ScrollView } from "react-native-gesture-handler";
import { COLORS } from "../../assets";
import NetworkStatus from "../../utilities/NetworkStatus";
import { horizontalScale, moderateScale, verticalScale } from "../Scaling";

const RecipeInstructions = ({ navigation, route }) => {
  const { instructions, bannerImageUrl } = route.params;

  useEffect(() => {
    const handleBackPress = () => {
      navigation.goBack();
      return true;
    };

    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () => {
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
    };
  }, []);

  return (
    <View style={styles.container}>
      <ScrollView
        decelerationRate="fast"
        style={{ width: "100%" }}
        contentContainerStyle={{
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Image source={{ uri: bannerImageUrl }} style={styles.image} />
        <Text style={styles.textStyle}>Instructions: </Text>

        <View style={styles.instructionsContainer}>
          {instructions.map((instruction, index) => (
            <View key={index} style={styles.itemContainer}>
              <Text style={styles.instruction}>{instruction}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
      <NetworkStatus />
    </View>
  );
};

export default RecipeInstructions;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "space-evenly",
    alignItems: "left",
    backgroundColor: COLORS.cream,
  },
  textStyle: {
    fontFamily: "LexendDeca-Bold",
    fontSize: moderateScale(22),
    color: COLORS.lightOrange,
    alignSelf: "flex-start",
    textAlign: "left",
    marginLeft: horizontalScale(30),
    paddingBottom: verticalScale(5),
  },
  image: {
    width: horizontalScale(340),
    height: verticalScale(190),
    marginVertical: verticalScale(20),
  },
  instructionsContainer: {
    marginVertical: verticalScale(20),
  },
  itemContainer: {
    width: "85%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginVertical: verticalScale(5),
    textAlign: "justify",
  },
  instruction: {
    fontSize: moderateScale(14),
    fontFamily: "LexendDeca-Medium",
    color: COLORS.lightOrange,
    textAlign: "justify",
    width: "100%",
  },
});
