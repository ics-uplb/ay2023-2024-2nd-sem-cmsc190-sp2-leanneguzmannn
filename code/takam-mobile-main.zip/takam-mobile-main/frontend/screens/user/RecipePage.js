import React, { useEffect } from "react";
import {
  BackHandler,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { ScrollView } from "react-native-gesture-handler";
import ROUTES from "../../../utilities/Routes";
import { COLORS, IMGS } from "../../assets";
import NetworkStatus from "../../utilities/NetworkStatus";
import { horizontalScale, moderateScale, verticalScale } from "../Scaling";

const RecipePage = ({ navigation, route }) => {
  const { recipe } = route.params;

  useEffect(() => {
    const handleBackPress = () => {
      navigation.goBack();
      return true;
    };

    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () => {
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
    };
  }, []);

  return (
    <View style={styles.container}>
      <ScrollView
        decelerationRate="fast"
        style={{ width: "100%" }}
        contentContainerStyle={{
          flex: 1,
          alignItems: "center",
          justifyContent: "space-evenly",
        }}
      >
        <Image source={{ uri: recipe.bannerImageUrl }} style={styles.image} />
        <View style={styles.rowContainer}>
          <View style={styles.outlineButton}>
            <Text style={styles.textStyle}>Difficulty</Text>
            <Image source={IMGS.DIFFICULTY} style={styles.imageIcon} />
            <Text style={styles.textStyle}>{recipe.difficulty}</Text>
          </View>
          <View style={styles.outlineButton}>
            <Text style={styles.textStyle}>Total Time</Text>
            <Image source={IMGS.TIME} style={styles.imageIcon} />
            <Text style={styles.textStyle}>{recipe.time} Minutes</Text>
          </View>
          <View style={styles.outlineButton}>
            <Text style={styles.textStyle}>Servings</Text>
            <Image source={IMGS.SERVING} style={styles.imageIcon} />
            <Text style={styles.textStyle}>{recipe.servings} People</Text>
          </View>
        </View>
        <View style={styles.rowContainer}>
          <TouchableOpacity
            onPress={() =>
              navigation.navigate(ROUTES.USER_INGREDIENTS, {
                recipe,
              })
            }
          >
            <Image source={IMGS.INGREDIENTS} style={styles.imageRecipeBody} />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() =>
              navigation.navigate(ROUTES.USER_INSTRUCTIONS, {
                instructions: recipe.instructions,
                bannerImageUrl: recipe.bannerImageUrl,
              })
            }
          >
            <Image source={IMGS.INSTRUCTIONS} style={styles.imageRecipeBody} />
          </TouchableOpacity>
        </View>
      </ScrollView>
      <NetworkStatus />
    </View>
  );
};

export default RecipePage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "space-evenly",
    alignItems: "center",
    backgroundColor: COLORS.cream,
  },
  textStyle: {
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(12),
    color: COLORS.lightOrange,
    textAlign: "center",
  },
  image: {
    width: horizontalScale(340),
    height: verticalScale(190),
  },
  rowContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-evenly",
    width: "90%",
  },
  outlineButton: {
    backgroundColor: "transparent",
    paddingHorizontal: moderateScale(6),
    padding: moderateScale(3),
    borderRadius: moderateScale(8),
    borderWidth: moderateScale(3),
    borderColor: COLORS.lightOrange,
    height: verticalScale(90),
    width: horizontalScale(90),
    alignItems: "center",
  },
  imageIcon: {
    width: horizontalScale(40),
    height: verticalScale(39),
    margin: moderateScale(5),
  },
  imageRecipeBody: {
    width: horizontalScale(150),
    height: verticalScale(240),
  },
});
