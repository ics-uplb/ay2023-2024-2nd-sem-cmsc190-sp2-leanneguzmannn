import React, { useEffect } from "react";
import { BackHandler, StyleSheet, Text, View } from "react-native";
import { Button } from "react-native-elements";
import { horizontalScale, moderateScale, verticalScale } from "./Scaling";
import { COLORS } from "../assets";
import CustomModal from "./CustomModal";

const CustomAlert = (props) => {
  const {
    navigation,
    visible,
    onRequestClose,
    onConfirm,
    animationType,
    transparent,
    title,
    subtitle,
    cancelBtnName,
    confirmBtnName,
    confirmBtnDisabled = false,
    alertContent,
    cancelEnabled,
  } = props;

  useEffect(() => {
    const handleBackPress = () => {
      navigation.goBack();
      return true;
    };

    BackHandler.addEventListener("hardwareBackPress", handleBackPress);

    return () => {
      BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
    };
  }, []);

  return (
    <CustomModal
      navigation={navigation}
      visible={visible}
      onRequestClose={onRequestClose}
      animationType={animationType}
      transparent={transparent}
      modalStyle={{
        minHeight: "20%",
        width: "80%",
      }}
      modalContent={
        <View>
          <View
            style={{
              alignItems: "center",
              marginHorizontal: horizontalScale(10),
            }}
          >
            <Text style={styles.titleStyle}>{title}</Text>
            <Text style={styles.subtitleStyle}>{subtitle}</Text>

            {alertContent}

            <View
              style={{
                flexDirection: "row",
                marginTop: verticalScale(20),
              }}
            >
              {cancelEnabled && (
                <Button
                  title={cancelBtnName ? cancelBtnName : "Cancel"}
                  titleStyle={{
                    fontFamily: "LexendDeca-Medium",
                    fontSize: moderateScale(13),
                    color: COLORS.cream,
                  }}
                  buttonStyle={{
                    minWidth: horizontalScale(50),
                    backgroundColor: COLORS.red,
                    marginHorizontal: horizontalScale(10),
                    borderRadius: moderateScale(5),
                  }}
                  onPress={onRequestClose}
                />
              )}

              <Button
                title={confirmBtnName ? confirmBtnName : "OK"}
                titleStyle={{
                  fontFamily: "LexendDeca-Medium",
                  fontSize: moderateScale(13),
                  color: COLORS.cream,
                }}
                buttonStyle={{
                  minWidth: horizontalScale(50),
                  backgroundColor: COLORS.green,
                  marginHorizontal: horizontalScale(10),
                  borderRadius: moderateScale(5),
                }}
                disabled={confirmBtnDisabled}
                onPress={onConfirm}
              />
            </View>
          </View>
        </View>
      }
    />
  );
};

export default CustomAlert;

const styles = StyleSheet.create({
  titleStyle: {
    fontFamily: "LexendDeca-Bold",
    fontSize: moderateScale(18),
    textAlign: "center",
    color: COLORS.brown,
    paddingBottom: verticalScale(10),
  },
  subtitleStyle: {
    fontFamily: "LexendDeca-Medium",
    fontSize: moderateScale(13),
    color: COLORS.brown,
    textAlign: "justify",
  },
});
