import { AppBar } from "@react-native-material/core";
import React from "react";
import { StyleSheet, Text, View, TouchableOpacity, Image } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { horizontalScale, moderateScale } from "./Scaling";
import { COLORS, IMGS } from "../assets";

const CustomAppBar = (props) => {
  const { navigation, name, titleImage, trailingIcon } = props;

  const insets = useSafeAreaInsets();

  return (
    <AppBar
      title={
        <View style={{ flexDirection: "row" }}>
          <Text style={[styles.appname, { color: COLORS.cream }]}>{name}</Text>
          {titleImage}
        </View>
      }
      centerTitle={true}
      color={COLORS.orange}
      style={{ paddingTop: insets.top, zIndex: 5 }}
      elevation={5}
      leading={
        <TouchableOpacity
          onPress={() => {
            navigation.openDrawer();
          }}
        >
          <View>
            <Image source={IMGS.MENU} style={styles.button} />
          </View>
        </TouchableOpacity>
      }
      trailing={trailingIcon}
    />
  );
};

export default CustomAppBar;

const styles = StyleSheet.create({
  appname: {
    fontFamily: "LexendDeca-SemiBold",
    fontStyle: "normal",
    fontSize: moderateScale(20),
    letterSpacing: horizontalScale(5),
  },
  button: {
    width: moderateScale(35),
    height: moderateScale(35),
    left: horizontalScale(10),
  },
});
