import {
  DrawerContentScrollView,
  DrawerItemList,
} from "@react-navigation/drawer";
import * as SecureStore from "expo-secure-store";
import { useFonts } from "expo-font";
import * as SplashScreen from "expo-splash-screen";
import React, { useCallback, useContext, useEffect } from "react";
import { StyleSheet, View, TouchableOpacity, Image } from "react-native";

import { FONTS, COLORS, IMGS } from "../assets";
import { horizontalScale, moderateScale, verticalScale } from "./Scaling";
import { auth } from "../../backend/firebase";
import listenerManager from "../../utilities/listenerManager";
import { UserContext } from "../../utilities/UserProvider";

const CustomDrawer = (props) => {
  const { setUser } = useContext(UserContext);
  const [fontsLoaded] = useFonts(FONTS);

  const handleLogout = async () => {
    try {
      // Delete user credentials and meal plan
      await SecureStore.deleteItemAsync("userAuthCred");
      await SecureStore.deleteItemAsync("mealPlan")

      // Clear all onSnapshot listeners
      listenerManager.removeListeners();
      auth.signOut().then(() => {
        setUser(null);
      });
    } catch (error) {
      console.error("Logout error:", error);
      alert("Error occurred during logout. Please try again.");
    }
  };

  useEffect(() => {
    async function prepare() {
      await SplashScreen.preventAutoHideAsync();
    }
    prepare();
  }, []);

  const onLayoutRootView = useCallback(async () => {
    if (fontsLoaded) {
      await SplashScreen.hideAsync();
    }
  }, [fontsLoaded]);

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View style={styles.sidebar} onLayoutRootView={onLayoutRootView}>
      <DrawerContentScrollView {...props} contentContainerStyle={styles.list}>
        <DrawerItemList {...props} style={styles.menu} />
      </DrawerContentScrollView>
      <View style={styles.bottomctn}>
        <TouchableOpacity onPress={handleLogout} style={styles.button}>
          <Image source={IMGS.SIGNOUT} style={styles.button} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default CustomDrawer;

const styles = StyleSheet.create({
  sidebar: {
    flex: 1,
    backgroundColor: COLORS.orange,
  },
  logo: {
    width: horizontalScale(200),
    height: verticalScale(100),
    justifyContent: "flex-start",
    marginVertical: verticalScale(20),
  },
  bottom: {
    padding: moderateScale(20),
    borderTopWidth: horizontalScale(1),
    borderTopColor: "#ccc",
  },
  logout_btn: {
    paddingVertical: verticalScale(10),
    borderRadius: 5,
    width: "100%",
  },
  logout_txt: {
    fontFamily: "LexendDeca-Medium",
    fontStyle: "normal",
    fontWeight: 400,
    fontSize: moderateScale(12),
    marginLeft: horizontalScale(15),
  },
  button: {
    width: horizontalScale(200),
    height: verticalScale(40),
  },
  bottomctn: {
    justifyContent: "center",
    alignItems: "center",
    bottom: verticalScale(60),
  },
  menu: {
    width: verticalScale(160),
  },
});
