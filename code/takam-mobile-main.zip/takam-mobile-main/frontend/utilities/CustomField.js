import React from "react";
import { StyleSheet, Text, TextInput, View } from "react-native";
import { horizontalScale, moderateScale, verticalScale } from "./Scaling";
import { useState } from "react";

const CustomField = ({
  containerStyle,
  label,
  placeholder,
  defaultValue,
  customHeight,
  customWidth,
  editable,
  inputStyle,
  labelStyle,
  boxStyle,
  prependComponent,
  appendComponent,
  onChangeText,
  secureTextEntry,
  keyboardType = "default",
  autoCompleteType = "off",
  autoCapitalize = "none",
  errorMsg = "",
}) => {
  const [inputHeight, setInputHeight] = useState(verticalScale(50));

  const handleContentSizeChange = (event) => {
    const { height } = event.nativeEvent.contentSize;
    setInputHeight(Math.max(verticalScale(50), height));
  };

  return (
    <View style={{ ...containerStyle }}>
      <View
        style={{
          flexDirection: "row",
          alignItems: "baseline",
          justifyContent: "space-between",
        }}
      >
        <Text style={{ color: "#FFE6AB", ...labelStyle }}>{label}</Text>
        <Text
          style={{
            color: "#FFE6AB",
            ...labelStyle,
            fontSize: moderateScale(10),
          }}
        >
          {errorMsg}
        </Text>
      </View>

      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          minHeight: customHeight ? customHeight : verticalScale(50),
          height: inputHeight,
          width: customWidth ? customWidth : horizontalScale(280),
          paddingHorizontal: horizontalScale(24),
          borderRadius: moderateScale(20),
          backgroundColor: "#A0551D",
          ...boxStyle,
        }}
      >
        {prependComponent}

        <TextInput
          style={{ flex: 1, ...inputStyle, height: inputHeight }}
          value={defaultValue}
          placeholder={placeholder}
          placeholderTextColor={"#FFE6AB"}
          secureTextEntry={secureTextEntry}
          keyboardType={keyboardType}
          autoCompleteType={autoCompleteType}
          autoCapitalize={autoCapitalize}
          editable={editable}
          onChangeText={(text) => onChangeText(text)}
          onContentSizeChange={
            label === "Remarks" ? handleContentSizeChange : null
          }
        />

        {appendComponent}
      </View>
    </View>
  );
};

export default CustomField;

const styles = StyleSheet.create({});
