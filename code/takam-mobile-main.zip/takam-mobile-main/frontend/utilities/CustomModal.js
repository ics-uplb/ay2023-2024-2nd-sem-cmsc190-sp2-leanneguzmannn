import { AntDesign } from "@expo/vector-icons";
import React, { useEffect } from "react";
import { Modal, StyleSheet, TouchableOpacity, View } from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from "react-native-reanimated";
import { horizontalScale, moderateScale, verticalScale } from "./Scaling";
import { COLORS, FONTS, IMGS } from "../assets";

const CustomModal = ({
  visible,
  onRequestClose,
  animationType,
  transparent,
  modalStyle,
  modalContent,
}) => {
  const animatedValue = useSharedValue(0);
  const animatedModal = useAnimatedStyle(() => {
    return {
      transform: [{ scale: animatedValue.value }],
    };
  });

  const toggleModal = () => {
    if (visible) {
      animatedValue.value = withSpring(1, { duration: 300 });
    } else {
      setTimeout(onRequestClose, 200);
      animatedValue.value = withTiming(0, { duration: 300 });
    }
  };

  useEffect(() => {
    toggleModal();
  }, [visible]);

  return (
    <Modal
      visible={visible}
      onRequestClose={onRequestClose}
      animationType={animationType}
      transparent={transparent}
    >
      <View
        style={{
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: COLORS.gray + "AA",
        }}
      >
        <Animated.View
          style={[styles.modalView, { ...modalStyle }, animatedModal]}
        >
          <TouchableOpacity onPress={onRequestClose}>
            <View
              style={{ alignSelf: "flex-end", marginBottom: verticalScale(10) }}
            >
              <AntDesign
                name="close"
                size={moderateScale(24)}
                color={COLORS.black}
              />
            </View>
          </TouchableOpacity>
          {modalContent}
        </Animated.View>
      </View>
    </Modal>
  );
};

export default CustomModal;

const styles = StyleSheet.create({
  modalView: {
    backgroundColor: COLORS.cream,
    borderColor: COLORS.brown,
    borderWidth: moderateScale(3),
    borderRadius: moderateScale(20),
    padding: moderateScale(10),

    shadowColor: COLORS.black,
    shadowOffset: {
      width: 0,
      height: verticalScale(2),
    },
    shadowOpacity: 0.5,
    shadowRadius: moderateScale(4),
    elevation: moderateScale(5),
  },
});
