import NetInfo from "@react-native-community/netinfo";
import React, { useEffect, useState } from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { Button } from "react-native-elements";
import { horizontalScale, moderateScale, verticalScale } from "./Scaling";
import { COLORS, FONTS, IMGS } from "../assets";

const NetworkStatus = () => {
  const [isConnected, setIsConnected] = useState(true);

  const checkConnection = () => {
    NetInfo.fetch().then((state) => {
      console.log("Connection type: ", state.type);
      console.log("Connected?: ", state.isConnected);
      setIsConnected(state.isConnected);
    });
  };

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener((state) => {
      setIsConnected(state.isConnected);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  if (isConnected) {
    return null; // No need to render anything when connected
  }

  return (
    <View style={styles.container}>
      <View style={{ marginBottom: verticalScale(20) }}>
        <Image
          source={IMGS.WIFI}
          style={styles.noInternetIcon}
          // resizeMode="contain"
        />
      </View>

      <View style={{ marginVertical: verticalScale(5), alignItems: "center" }}>
        <Text style={styles.connectionText}>No Internet Connection</Text>
        <Text style={styles.connectionSubtext}>
          Please change to an available network connection.
        </Text>
      </View>

      <View style={{ marginVertical: verticalScale(10) }}>
        <Button
          title="RELOAD"
          titleStyle={[styles.buttonText, { color: COLORS.cream }]}
          buttonStyle={{
            width: horizontalScale(150),
            backgroundColor: COLORS.orange,
            borderColor: COLORS.orange,
            borderWidth: 1,
            borderRadius: moderateScale(10),
            overflow: "hidden",
          }}
          disabled={false}
          disabledStyle={{
            borderColor: COLORS.lightGray3,
            backgroundColor: COLORS.lightGray3,
          }}
          onPress={checkConnection}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.cream,
  },
  noInternetIcon: {
    height: verticalScale(200),
    aspectRatio: 1,
  },
  connectionText: {
    fontFamily: "LexendDeca-SemiBold",
    fontStyle: "normal",
    fontSize: moderateScale(22),
    fontWeight: "400",
    color: COLORS.red,
  },
  connectionSubtext: {
    fontFamily: "LexendDeca-Regular",
    fontStyle: "normal",
    fontSize: moderateScale(15),
    fontWeight: "400",
    textAlign: "center",
    color: COLORS.darkBrown,
  },
  buttonText: {
    fontFamily: "LexendDeca-Medium",
    fontStyle: "normal",
    fontSize: moderateScale(14),
    fontWeight: "500",
  },
});

export default NetworkStatus;
