import { useEffect } from "react";
import { useToast } from "react-native-toast-notifications";

const CustomToast = ({ notification }) => {
  const toast = useToast();

  useEffect(() => {
    if (notification) {
      toast.show(notification.body, {
        type: "custom_toast",
        animationDuration: 200,
        duration: 6000,
        data: {
          title: notification.title,
        },
        onHide: () => {
          // Reset the notification message after it's hidden
          setNotificationMessage({});
        },
      });
    }
  }, [notification, toast]);

  return null;
};

export default CustomToast;
