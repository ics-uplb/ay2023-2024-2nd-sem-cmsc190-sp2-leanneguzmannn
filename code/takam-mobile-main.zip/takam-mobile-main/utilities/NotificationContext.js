import React, { createContext, useContext, useState } from "react";

const NotificationContext = createContext();

export const NotificationProvider = ({ children }) => {
  const [notificationMessage, setNotificationMessage] = useState({});

  return (
    <NotificationContext.Provider
      value={{ notificationMessage, setNotificationMessage }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotification = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error(
      "useNotification must be used within a NotificationProvider"
    );
  }
  return context;
};

// import React, { createContext, useContext, useState } from "react";

// const NotificationContext = createContext();

// export const NotificationProvider = ({ children }) => {
//   const [notificationMessage, setNotificationMessage] = useState({});

//   const setNotification = (newNotification, callback) => {
//     setNotificationMessage(newNotification);
//     // Call the callback function if it's provided
//     if (callback && typeof callback === "function") {
//       callback();
//     }
//   };

//   return (
//     <NotificationContext.Provider value={{ notification: notificationMessage, setNotification }}>
//       {children}
//     </NotificationContext.Provider>
//   );
// };

// export const useNotification = () => useContext(NotificationContext);
