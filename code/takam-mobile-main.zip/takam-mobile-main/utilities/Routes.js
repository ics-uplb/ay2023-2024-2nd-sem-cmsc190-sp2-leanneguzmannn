export default {
  SPLASHSCREEN: "SplashScreen",
  WELCOME: "Welcome",
  SIGNIN: "Signin",
  SIGNUP: "Signup",
  FORGOT_PASSWORD: "ForgotPassword",
  LOADING: "Loading",
  UNAUTHORIZED: "Unauthorized",

  USER_SIDEBAR_NAVIGATOR: "UserSidebarNavigator",

  USER_HOME_NAVIGATOR: "UserHomeNavigator",
  USER_HOME: "UserHome",

  USER_INVENTORY_NAVIGATOR: "UserInventoryNavigator",
  USER_INVENTORY: "UserInventory",
  USER_ADD_INVENTORY: "UserAddInventory",

  USER_RECIPE_NAVIGATOR: "UserRecipeNavigator",
  USER_RECIPE: "UserRecipe",
  USER_RECIPEPAGE: "UserRecipePage",
  USER_INGREDIENTS: "UserRecipeIngredients",
  USER_INSTRUCTIONS: "UserRecipeInstructions",

  USER_MEALPLAN_NAVIGATOR: "UserMealPlanNavigator",
  USER_MEALPLAN: "UserMealPlan",

  USER_GROCERY_NAVIGATOR: "UserGroceryNavigator",
  USER_GROCERY: "UserGrocery",

  USER_HISTORY_NAVIGATOR: "UserHistoryNavigator",
  USER_HISTORY: "UserHistory",

  USER_NOTIFICATIONS_NAVIGATOR: "UserNotificationsNavigator",
  USER_NOTIFICATIONS: "UserNotifications",
};
