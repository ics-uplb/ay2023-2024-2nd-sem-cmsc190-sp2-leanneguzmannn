import firebase from "firebase/compat/app";
import moment from "moment";

export const formatFirebaseTimestamp = (firebaseTimestamp) => {
  const date = new Date(
    firebaseTimestamp.seconds * 1000 + firebaseTimestamp.nanoseconds / 1000000
  );
  return moment(date).format("MM/DD/YYYY");
};

export const stringToFirebaseTimestamp = (dateString) => {
  // Parse the date string manually
  const parts = dateString.split("/");
  const year = parseInt(parts[2], 10);
  const month = parseInt(parts[0], 10) - 1; // Months are zero-based in JavaScript Date objects
  const day = parseInt(parts[1], 10);

  // Create the Date object
  const dateObject = new Date(year, month, day);

  // Convert the Date object into a Firebase Timestamp
  const firebaseTimestamp = firebase.firestore.Timestamp.fromDate(dateObject);

  return firebaseTimestamp;
};
