const listeners = [];

function addListener(listener) {
  listeners.push(listener);
}

function removeListeners() {
  listeners.forEach((listener) => {
    if (typeof listener === "function") {
      listener();
    }
  });
  listeners.length = 0; // Clear the listeners array
}

const listenerManager = {
  addListener,
  removeListeners,
};

export default listenerManager;
